import express from 'express';
import path from 'node:path';
import { AGENT_KEYS, IS_PROD, MODELS, PORT } from './server/config';
import { api } from './server/routes';

async function main() {
  const app = express();
  app.use('/api', api);

  if (IS_PROD) {
    const dist = path.resolve(process.cwd(), 'dist');
    app.use(express.static(dist));
    app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
  } else {
    // Dev: Vite runs inside this server, so the site and /api share one port
    const { createServer } = await import('vite');
    const vite = await createServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('AI models in use:', JSON.stringify(MODELS));
    for (const [agent, key] of Object.entries(AGENT_KEYS)) {
      if (!key) console.warn(`AI agent "${agent}": no Groq key set (GROQ_KEY_${agent.toUpperCase()}), it will not work.`);
      else if (!key.startsWith('gsk_')) console.warn(`AI agent "${agent}": key does not start with "gsk_", Groq will probably reject it.`);
    }
  });
}

main();
