/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DISASTER_ZONES, DisasterZoneDetail } from './data/disasterData';
import { OrbitIntro } from './components/OrbitIntro';
import { HeroSection } from './components/HeroSection';
import { DashboardSection } from './components/DashboardSection';
import { CommunityReportingSection } from './components/CommunityReportingSection';
import { ResourceAllocationSection } from './components/ResourceAllocationSection';
import { AboutConstellationSection } from './components/AboutConstellationSection';
import { Footer } from './components/Footer';
import { AiVoiceAssistantModal } from './components/AiVoiceAssistantModal';
import { DemoShowreelModal } from './components/DemoShowreelModal';
import { SearchAreaModal } from './components/SearchAreaModal';
import { MapLayerKey, SECTION_IDS, UiAction, sendMapCommand } from './ai/uiActions';

export default function App() {
  const [activeZoneIndex, setActiveZoneIndex] = useState<number>(0);
  const [selectionMode, setSelectionMode] = useState<boolean>(false);
  const [isVoiceAssistantOpen, setIsVoiceAssistantOpen] = useState<boolean>(false);
  const [isDemoShowreelOpen, setIsDemoShowreelOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const activeZone = DISASTER_ZONES[activeZoneIndex] || DISASTER_ZONES[0];

  const handlePrevZone = () => {
    setActiveZoneIndex(prev => (prev === 0 ? DISASTER_ZONES.length - 1 : prev - 1));
  };

  const handleNextZone = () => {
    setActiveZoneIndex(prev => (prev === DISASTER_ZONES.length - 1 ? 0 : prev + 1));
  };

  const handleSelectZone = (zone: DisasterZoneDetail) => {
    const idx = DISASTER_ZONES.findIndex(z => z.id === zone.id);
    if (idx !== -1) {
      setActiveZoneIndex(idx);
    }
  };

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Runs the website actions the AI assistant asked for (navigation, zones, search, map)
  const handleAiActions = (actions: UiAction[]) => {
    if (actions.length === 0) return;

    for (const { name, args } of actions) {
      switch (name) {
        case 'navigate_section': {
          const id = SECTION_IDS[String(args.section)];
          if (id) handleNavigateSection(id);
          break;
        }
        case 'select_zone': {
          const idx = DISASTER_ZONES.findIndex(z => z.id === args.zone_id);
          if (idx !== -1) {
            setActiveZoneIndex(idx);
            handleNavigateSection('hero-section');
          }
          break;
        }
        case 'open_search':
          setSearchQuery(typeof args.query === 'string' ? args.query : '');
          setIsSearchOpen(true);
          break;
        case 'open_demo_showreel':
          setIsDemoShowreelOpen(true);
          break;
        case 'toggle_selection_mode':
          setSelectionMode(Boolean(args.enabled));
          break;
        case 'map_fly_to':
          handleNavigateSection('hero-section');
          sendMapCommand({ type: 'flyTo', lat: Number(args.lat), lng: Number(args.lng), zoom: args.zoom ? Number(args.zoom) : undefined });
          break;
        case 'map_set_layer':
          handleNavigateSection('hero-section');
          sendMapCommand({ type: 'setLayer', layer: args.layer as MapLayerKey });
          break;
        case 'map_analyze':
          handleNavigateSection('hero-section');
          sendMapCommand({ type: 'analyze', lat: Number(args.lat), lng: Number(args.lng) });
          break;
      }
    }

    // Close the chat so the user can see what the AI just did
    setIsVoiceAssistantOpen(false);
  };

  const handleStartAnalysis = () => {
    setSelectionMode(true);
    handleNavigateSection('hero-section');
  };

  return (
    <div className="min-h-screen bg-[#d8cec4] text-[#1c1b18] antialiased selection:bg-stone-800 selection:text-white">
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div
          className="absolute inset-0 opacity-40 bg-cover bg-center filter grayscale contrast-125"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=2000&q=80')`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#d8cec4]/90 via-[#dfd6cd]/95 to-[#d3c8bd]/95" />
      </div>

      {/* Cinematic scroll intro: Sun, orbiting Earth, dive into the planet */}
      <OrbitIntro />

      {/* Main Page Layout */}
      <main className="relative z-10 w-full overflow-x-hidden pt-3 sm:pt-6">
        
        {/* 1. Flagship Hero Section matching Reference Image layout */}
        <HeroSection
          zones={DISASTER_ZONES}
          activeZoneIndex={activeZoneIndex}
          onPrevZone={handlePrevZone}
          onNextZone={handleNextZone}
          onSelectZone={handleSelectZone}
          onOpenVoiceAssistant={() => setIsVoiceAssistantOpen(true)}
          onOpenDemoShowreel={() => setIsDemoShowreelOpen(true)}
          onNavigateSection={handleNavigateSection}
          selectionMode={selectionMode}
          onToggleSelectionMode={() => setSelectionMode(!selectionMode)}
          onStartAnalysis={handleStartAnalysis}
          onSearchClick={() => setIsSearchOpen(true)}
        />

        {/* 2. Step-down Scroll Reveal: Real-time Disaster Dashboard */}
        <DashboardSection
          zones={DISASTER_ZONES}
          onSelectZone={handleSelectZone}
          activeZoneId={activeZone.id}
        />

        {/* 3. Step-down Scroll Reveal: Community Ground-Truthing Hub */}
        <CommunityReportingSection />

        {/* 4. Step-down Scroll Reveal: AI Emergency Resource Allocation Engine */}
        <ResourceAllocationSection />

        {/* 5. Step-down Scroll Reveal: NASA Space Apps Constellation Architecture */}
        <AboutConstellationSection />

        {/* Footer */}
        <Footer />
      </main>

      {/* Interactive Modals */}
      <AiVoiceAssistantModal
        isOpen={isVoiceAssistantOpen}
        onClose={() => setIsVoiceAssistantOpen(false)}
        activeZone={activeZone}
        onUiActions={handleAiActions}
      />

      <DemoShowreelModal
        isOpen={isDemoShowreelOpen}
        onClose={() => setIsDemoShowreelOpen(false)}
      />

      <SearchAreaModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        zones={DISASTER_ZONES}
        onSelectZone={handleSelectZone}
        initialQuery={searchQuery}
      />
    </div>
  );
}
