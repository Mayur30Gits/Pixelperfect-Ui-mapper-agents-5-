import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDisasterSeverity,
  estimateRescueResourceNeeds,
  formatCoordinates,
  calculateDistanceKm,
  findNearestDisasterZone
} from './disasterCalculations.ts';

test('calculateDisasterSeverity categorizes severe flood accurately', () => {
  // Extreme hazard (intensity 5, high vulnerability 0.9, 800k pop, low readiness 20)
  const result = calculateDisasterSeverity(5, 0.9, 800000, 20);
  assert.equal(result.tier, 'Critical');
  assert.ok(result.score >= 75, `Expected score >= 75, got ${result.score}`);
});

test('calculateDisasterSeverity returns Low for minimal hazard with strong readiness', () => {
  const result = calculateDisasterSeverity(1, 0.1, 500, 95);
  assert.equal(result.tier, 'Low');
  assert.ok(result.score < 25, `Expected score < 25, got ${result.score}`);
});

test('estimateRescueResourceNeeds computes human water and medical team needs according to Sphere standards', () => {
  const estimates = estimateRescueResourceNeeds(100000, 80, 500);
  assert.equal(estimates.priorityLevel, 'Immediate');
  assert.ok(estimates.sheltersNeeded > 0);
  assert.ok(estimates.waterRationsLitersPerDay > 0);
  assert.ok(estimates.medicalEmergencyTeams >= 2);
  assert.ok(estimates.evacuationRoutesCount >= 2);
});

test('formatCoordinates returns formatted latitude and longitude string', () => {
  const formatted = formatCoordinates(39.4699, -0.3763);
  assert.equal(formatted, '39.4699° N, 0.3763° W');

  const southern = formatCoordinates(-33.8688, 151.2093);
  assert.equal(southern, '33.8688° S, 151.2093° E');
});

test('calculateDistanceKm computes distance accurately', () => {
  // Madrid (40.4168, -3.7038) to Valencia (39.4699, -0.3763) is approx 300-310 km
  const dist = calculateDistanceKm(40.4168, -3.7038, 39.4699, -0.3763);
  assert.ok(dist >= 290 && dist <= 320, `Expected ~302km, got ${dist}`);
});

test('findNearestDisasterZone correctly identifies closest hazard zone', () => {
  const testZones = [
    { name: 'Valencia Flood', coordinates: [39.4699, -0.3763] as [number, number] },
    { name: 'Tokyo Alert', coordinates: [35.6762, 139.6503] as [number, number] },
    { name: 'New York Storm', coordinates: [40.7128, -74.006] as [number, number] }
  ];

  // User in Barcelona (41.3851, 2.1734) -> closest to Valencia
  const nearest = findNearestDisasterZone(41.3851, 2.1734, testZones);
  assert.ok(nearest !== null);
  assert.equal(nearest.zone.name, 'Valencia Flood');
  assert.ok(nearest.distanceKm < 350);
});
