export interface DisasterZone {
  id: string;
  name: string;
  country: string;
  hazardType: 'flood' | 'wildfire' | 'cyclone' | 'earthquake' | 'landslide' | 'drought';
  coordinates: [number, number]; // [lat, lng]
  affectedAreaKm2: number;
  populationAtRisk: number;
  readinessScore: number; // 0 to 100
  hazardIntensity: number; // 1 to 5 scale
  vulnerabilityIndex: number; // 0 to 1 scale
  status: 'critical' | 'alert' | 'monitored' | 'contained';
  satelliteMission: string; // e.g. "Sentinel-1 SAR + Landsat-9"
  lastUpdated: string;
  summary: string;
}

export type RiskTier = 'Low' | 'Moderate' | 'High' | 'Critical';

export interface ResourceAllocationEstimate {
  sheltersNeeded: number;
  waterRationsLitersPerDay: number;
  medicalEmergencyTeams: number;
  evacuationRoutesCount: number;
  priorityLevel: 'Immediate' | 'Urgent' | 'Standard';
}

/**
 * Calculates a composite disaster risk severity score from 0 to 100.
 */
export function calculateDisasterSeverity(
  hazardIntensity: number, // 1 to 5
  vulnerabilityIndex: number, // 0 to 1
  populationAtRisk: number,
  readinessScore: number // 0 to 100 (higher means better prepared)
): { score: number; tier: RiskTier } {
  // Normalize intensity to 0-1
  const normIntensity = Math.min(Math.max(hazardIntensity / 5, 0), 1);
  const normVuln = Math.min(Math.max(vulnerabilityIndex, 0), 1);
  
  // Population scale factor (logarithmic up to 1M)
  const popFactor = Math.min(Math.log10(Math.max(populationAtRisk, 10)) / 6, 1);
  
  // Inverse readiness: less readiness means higher risk
  const unreadiness = Math.max(0, (100 - readinessScore) / 100);

  // Weighted calculation
  const rawScore = (normIntensity * 0.4 + normVuln * 0.25 + popFactor * 0.2 + unreadiness * 0.15) * 100;
  const score = Math.round(Math.min(100, Math.max(0, rawScore)));

  let tier: RiskTier = 'Low';
  if (score >= 75) tier = 'Critical';
  else if (score >= 50) tier = 'High';
  else if (score >= 25) tier = 'Moderate';

  return { score, tier };
}

/**
 * Estimates humanitarian relief and evacuation resources required based on population and severity.
 */
export function estimateRescueResourceNeeds(
  affectedPopulation: number,
  severityScore: number,
  areaKm2: number
): ResourceAllocationEstimate {
  const safePop = Math.max(0, affectedPopulation);
  const severityMultiplier = Math.max(0.2, severityScore / 100);

  // Sphere humanitarian standard: 15L clean drinking water per person/day
  const displacedEstimate = Math.round(safePop * severityMultiplier * 0.35);
  const waterRationsLitersPerDay = displacedEstimate * 15;

  // Approx 150 people per collective emergency shelter
  const sheltersNeeded = Math.ceil(displacedEstimate / 150);

  // 1 specialized emergency response unit per 1,500 displaced persons + spatial factor
  const spatialTeams = Math.ceil(areaKm2 / 250);
  const medicalEmergencyTeams = Math.max(1, Math.ceil(displacedEstimate / 1500) + spatialTeams);

  const evacuationRoutesCount = Math.max(2, Math.min(8, Math.ceil(areaKm2 / 100)));

  const priorityLevel = severityScore >= 75 ? 'Immediate' : severityScore >= 45 ? 'Urgent' : 'Standard';

  return {
    sheltersNeeded,
    waterRationsLitersPerDay,
    medicalEmergencyTeams,
    evacuationRoutesCount,
    priorityLevel
  };
}

/**
 * Formats geographical coordinates into clean GPS/N-S E-W representation.
 */
export function formatCoordinates(lat: number, lng: number): string {
  const latDir = lat >= 0 ? 'N' : 'S';
  const lngDir = lng >= 0 ? 'E' : 'W';
  return `${Math.abs(lat).toFixed(4)}° ${latDir}, ${Math.abs(lng).toFixed(4)}° ${lngDir}`;
}

/**
 * Calculates distance in kilometers between two GPS coordinates using the Haversine formula.
 */
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

/**
 * Finds the nearest disaster zone to the user's location.
 */
export function findNearestDisasterZone<T extends { coordinates: [number, number]; name: string }>(
  userLat: number,
  userLng: number,
  zones: T[]
): { zone: T; distanceKm: number } | null {
  if (!zones || zones.length === 0) return null;
  let nearest: T = zones[0];
  let minDistance = calculateDistanceKm(userLat, userLng, zones[0].coordinates[0], zones[0].coordinates[1]);

  for (let i = 1; i < zones.length; i++) {
    const dist = calculateDistanceKm(userLat, userLng, zones[i].coordinates[0], zones[i].coordinates[1]);
    if (dist < minDistance) {
      minDistance = dist;
      nearest = zones[i];
    }
  }

  return { zone: nearest, distanceKm: minDistance };
}
