export interface DisasterZoneDetail {
  id: string;
  name: string;
  location: string;
  country: string;
  hazardType: 'flood' | 'wildfire' | 'cyclone' | 'earthquake' | 'landslide' | 'drought';
  coordinates: [number, number];
  areaKm2: number;
  populationAtRisk: number;
  readinessScore: number;
  hazardIntensity: number;
  vulnerabilityIndex: number;
  status: 'Critical Alert' | 'Emergency Monitored' | 'Contained';
  satelliteMission: string;
  imageUrl: string;
  satelliteOverlayUrl: string;
  summary: string;
  damageHighlights: string[];
  respondersOnSite: number;
  waterNeedLiters: number;
  sheltersNeeded: number;
  urgencyLevel: 'Immediate' | 'High' | 'Moderate';
}

export const DISASTER_ZONES: DisasterZoneDetail[] = [
  {
    id: 'valencia-floods',
    name: 'Valencia Basin Flash Floods',
    location: 'Turia River Catchment, Valencia',
    country: 'Spain',
    hazardType: 'flood',
    coordinates: [39.4699, -0.3763],
    areaKm2: 380,
    populationAtRisk: 145000,
    readinessScore: 35,
    hazardIntensity: 4.8,
    vulnerabilityIndex: 0.78,
    status: 'Critical Alert',
    satelliteMission: 'Sentinel-1 SAR + SWOT Radar',
    imageUrl: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    summary: 'High-resolution SAR analysis indicates 14,200 ha submerged. Priority rescue corridors identified along the Turia corridor.',
    damageHighlights: [
      '14,200 hectares critical agricultural and urban inundation',
      'Bridge collapse risk on 4 arterial transit corridors',
      'Rapid SAR backscatter differential confirms 1.8m peak surge'
    ],
    respondersOnSite: 24,
    waterNeedLiters: 760000,
    sheltersNeeded: 48,
    urgencyLevel: 'Immediate'
  },
  {
    id: 'lahaina-wildfire',
    name: 'Maui Lahaina Wildfire Perimeter',
    location: 'West Maui, Hawaii',
    country: 'United States',
    hazardType: 'wildfire',
    coordinates: [20.8783, -156.6825],
    areaKm2: 125,
    populationAtRisk: 18000,
    readinessScore: 42,
    hazardIntensity: 4.9,
    vulnerabilityIndex: 0.82,
    status: 'Critical Alert',
    satelliteMission: 'Landsat-9 Thermal TIRS-2 + VIIRS Active Fire',
    imageUrl: 'https://images.unsplash.com/photo-1542385151-efd9000785a0?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1606787366850-de6330128bfc?auto=format&fit=crop&w=800&q=80',
    summary: 'Thermal infrared sensors detected 850°C heat anomalies. 2,200 residential structures threatened along coastal perimeter.',
    damageHighlights: [
      '2,200 structures within high-probability burn envelope',
      'Downslope gale gusts exceeding 60 knots recorded by NOAA GOES',
      'Harbor evacuation routes secured by civil maritime guard'
    ],
    respondersOnSite: 42,
    waterNeedLiters: 195000,
    sheltersNeeded: 16,
    urgencyLevel: 'Immediate'
  },
  {
    id: 'turkey-fault',
    name: 'East Anatolian Seismic Fault Rift',
    location: 'Kahramanmaraş & Hatay Province',
    country: 'Türkiye',
    hazardType: 'earthquake',
    coordinates: [37.5858, 36.9371],
    areaKm2: 1200,
    populationAtRisk: 420000,
    readinessScore: 28,
    hazardIntensity: 5.0,
    vulnerabilityIndex: 0.91,
    status: 'Critical Alert',
    satelliteMission: 'Sentinel-1 InSAR Surface Deformation',
    imageUrl: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
    summary: 'Interferometric SAR maps 4.2m horizontal fault slip. Structural collapse density highest across Hatay basin.',
    damageHighlights: [
      'Fault dislocation mapped across 300km surface rupture',
      'Over 6,400 multi-story complexes damaged or compromised',
      'Seismic aftershock probability modeled at 78% over 72 hours'
    ],
    respondersOnSite: 110,
    waterNeedLiters: 2200000,
    sheltersNeeded: 180,
    urgencyLevel: 'Immediate'
  },
  {
    id: 'cyclone-remal',
    name: 'Bay of Bengal Cyclone Remal',
    location: 'Sundarbans Coastal Delta',
    country: 'Bangladesh & India',
    hazardType: 'cyclone',
    coordinates: [21.9497, 89.1833],
    areaKm2: 890,
    populationAtRisk: 680000,
    readinessScore: 58,
    hazardIntensity: 4.4,
    vulnerabilityIndex: 0.85,
    status: 'Emergency Monitored',
    satelliteMission: 'NASA GPM Core Observatory + INSAT-3D',
    imageUrl: 'https://images.unsplash.com/photo-1527482797697-8795b05a13fe?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=800&q=80',
    summary: 'Tidal surge inundated 45 polder embankments. Mangrove buffer reduced storm energy by 35% in coastal buffer zone.',
    damageHighlights: [
      '3.5m tidal storm surge overtopping saline embankments',
      'Salinization detected across 42,000 hectares of cropland',
      'Early automated SMS warnings evacuated 410,000 residents'
    ],
    respondersOnSite: 65,
    waterNeedLiters: 3400000,
    sheltersNeeded: 220,
    urgencyLevel: 'High'
  },
  {
    id: 'amazon-wildfire',
    name: 'Pantanal & Amazon Fire Front',
    location: 'Mato Grosso do Sul Basin',
    country: 'Brazil',
    hazardType: 'wildfire',
    coordinates: [-16.5167, -56.5167],
    areaKm2: 2400,
    populationAtRisk: 45000,
    readinessScore: 40,
    hazardIntensity: 4.2,
    vulnerabilityIndex: 0.72,
    status: 'Emergency Monitored',
    satelliteMission: 'MODIS Aqua/Terra + Sentinel-2 MSI Multi-Spectral',
    imageUrl: 'https://images.unsplash.com/photo-1473448912268-2022ce9509d8?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80',
    summary: 'Prolonged biome drought combined with shifting winds drove 12 distinct fire lines across wetland corridors.',
    damageHighlights: [
      '2.4 million hectares of biodiversity sanctuary affected',
      'Smoke aerosol optical depth (AOD) hazardous to inland airports',
      'Water bomber coordinates dynamically updated every 90 minutes'
    ],
    respondersOnSite: 38,
    waterNeedLiters: 420000,
    sheltersNeeded: 25,
    urgencyLevel: 'High'
  },
  {
    id: 'horn-africa-drought',
    name: 'Somali Regional Hydrological Deficit',
    location: 'Shabelle River Basin',
    country: 'Somalia & Ethiopia',
    hazardType: 'drought',
    coordinates: [5.1521, 46.1996],
    areaKm2: 6500,
    populationAtRisk: 890000,
    readinessScore: 22,
    hazardIntensity: 4.6,
    vulnerabilityIndex: 0.94,
    status: 'Emergency Monitored',
    satelliteMission: 'SMAP Soil Moisture + GRACE-FO Groundwater Gravity',
    imageUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?auto=format&fit=crop&w=1200&q=80',
    satelliteOverlayUrl: 'https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=800&q=80',
    summary: 'Consecutive failed monsoons reduced soil moisture to 8th percentile. Groundwater depletion accelerating pastoral distress.',
    damageHighlights: [
      'Surface reservoir water levels at lowest 20-year recorded volume',
      'Livestock mortality exceeding 40% across pastoral rangelands',
      'Emergency borehole solar pumps deployed to 18 community hubs'
    ],
    respondersOnSite: 19,
    waterNeedLiters: 4800000,
    sheltersNeeded: 140,
    urgencyLevel: 'Immediate'
  }
];

export type CommunityReportKind = 'Alert' | 'Damage' | 'Photo';

export interface CommunityReport {
  id: string;
  locationName: string;
  hazardType: string;
  severity: 'Critical' | 'Severe' | 'Moderate' | 'Minor';
  timestamp: string;
  reporter: string;
  verified: boolean;
  notes: string;
  coordinates?: [number, number];
  votes: number;
  kind?: CommunityReportKind;
  photoUrl?: string;
  createdAt?: number;
}

export const INITIAL_REPORTS: CommunityReport[] = [
  {
    id: 'rep-01',
    locationName: 'Paiporta Lower Canal, Valencia',
    hazardType: 'Flash Flood Overflow',
    severity: 'Critical',
    timestamp: '12 mins ago',
    reporter: 'Elena R. (Volunteer Rescuer)',
    verified: true,
    notes: 'Water depth reached 1.6m at intersection Calle Mayor. 12 elderly residents stranded on second floor balcony.',
    coordinates: [39.428, -0.419],
    votes: 42
  },
  {
    id: 'rep-02',
    locationName: 'Front Street, Lahaina',
    hazardType: 'Embers & Smoke Boundary',
    severity: 'Severe',
    timestamp: '28 mins ago',
    reporter: 'Koa M. (Coastline Watch)',
    verified: true,
    notes: 'Wind shift pushing thick black particulate towards bypass road. Evacuation convoy moving south.',
    coordinates: [20.876, -156.680],
    votes: 31
  },
  {
    id: 'rep-03',
    locationName: 'Antakya Central Hospital Ring',
    hazardType: 'Structural Damage & Road Block',
    severity: 'Critical',
    timestamp: '45 mins ago',
    reporter: 'Dr. T. Baran (Field Triage)',
    verified: true,
    notes: 'Debris blocking primary ambulance ingress. Generator power active. Oxygen supply needed.',
    coordinates: [36.202, 36.160],
    votes: 56
  },
  {
    id: 'rep-04',
    locationName: 'Mongla Port Sector 4',
    hazardType: 'Storm Surge Ingress',
    severity: 'Severe',
    timestamp: '1 hour ago',
    reporter: 'Rafiqul H. (Fisheries Union)',
    verified: true,
    notes: 'Tide level 2m above standard high-water line. Embankment breached at km marker 14.',
    coordinates: [22.483, 89.598],
    votes: 27
  }
];
