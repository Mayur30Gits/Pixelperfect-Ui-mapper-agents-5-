import React from 'react';
import { Satellite, Globe2, Radio, Cpu, Sparkles, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { motion } from 'motion/react';

export const AboutConstellationSection: React.FC = () => {
  const satellites = [
    {
      name: 'Sentinel-1 SAR',
      agency: 'ESA / Copernicus in collaboration with NASA',
      type: 'Synthetic Aperture Radar (C-Band)',
      altitude: '693 km Sun-Synchronous',
      resolution: '10m spatial resolution',
      role: 'Penetrates cloud cover, monsoons, and smoke plumes. Detects flood water backscatter and millimeter-scale seismic fault slips.',
      badge: 'ALL-WEATHER RADAR'
    },
    {
      name: 'Landsat-9',
      agency: 'NASA / USGS',
      type: 'Thermal Infrared (TIRS-2) & OLI-2',
      altitude: '705 km Polar Orbit',
      resolution: '15m - 30m multi-spectral',
      role: 'Measures land surface heat anomalies up to 850°C. Identifies active wildfire flame fronts, burn severity, and drought stress.',
      badge: 'THERMAL FLAME MAPPING'
    },
    {
      name: 'SWOT Radar',
      agency: 'NASA / CNES / CSA / UKSA',
      type: 'Ka-band Radar Interferometer (KaRIn)',
      altitude: '890 km Low Earth Orbit',
      resolution: 'Sub-meter water elevation precision',
      role: 'Maps global lakes, rivers, reservoirs, and flood inundation depth dynamics with unprecedented elevation vertical accuracy.',
      badge: 'HYDROLOGY TOPOGRAPHY'
    },
    {
      name: 'GPM Core Observatory',
      agency: 'NASA / JAXA',
      type: 'Dual-frequency Precipitation Radar & GMI',
      altitude: '407 km Inclined Orbit',
      resolution: '4km - 5km precipitation grid',
      role: 'Tracks extreme rainfall intensity, tropical cyclone tracks, and flash flood precipitation totals every 3 hours.',
      badge: 'PRECIPITATION RADAR'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: 'easeOut' as const }
    }
  };

  return (
    <section id="about-section" className="relative w-full max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.15 }}
        variants={containerVariants}
        className="rounded-[36px] bg-[#f4ece3] border border-white/60 p-6 sm:p-10 shadow-xl"
      >
        {/* Step 1: Section Header */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-[#ded3c6]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-tech font-bold">
                NASA SPACE APPS CHALLENGE
              </span>
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl font-light text-[#1c1b18] tracking-tight">
              Constellation & AI Architecture
            </h2>
            <p className="text-stone-600 text-sm mt-2 max-w-xl">
              Engineered for the NASA Space Apps Hackathon to transform open Earth observation datasets into actionable life-saving intelligence for tactical humanitarian response.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-white/70 px-4 py-2 rounded-full border border-white/80 text-xs font-tech text-stone-700">
            <Cpu className="w-4 h-4 text-amber-600" />
            <span>NEURAL DAMAGE PIPELINE V2.4</span>
          </div>
        </motion.div>

        {/* Step 2: Satellites Grid */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8">
          {satellites.map((sat, idx) => (
            <div
              key={idx}
              className="bg-white/95 rounded-[28px] p-6 border border-white/80 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="bg-[#1c1b18] text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider font-tech">
                    {sat.badge}
                  </span>
                  <span className="text-xs text-stone-400 font-tech">{sat.agency}</span>
                </div>

                <h3 className="text-lg font-bold text-[#1c1b18] mb-1">
                  {sat.name}
                </h3>
                <div className="text-xs text-amber-800 font-medium mb-3">
                  {sat.type}
                </div>

                <p className="text-xs text-stone-600 leading-relaxed">
                  {sat.role}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-stone-100 grid grid-cols-2 gap-2 text-[11px] font-tech text-stone-600">
                <div>
                  <span className="text-stone-400 block text-[9px] uppercase">Orbit</span>
                  <span className="font-semibold text-stone-800">{sat.altitude}</span>
                </div>
                <div>
                  <span className="text-stone-400 block text-[9px] uppercase">Resolution</span>
                  <span className="font-semibold text-stone-800">{sat.resolution}</span>
                </div>
              </div>
            </div>
          ))}
        </motion.div>

        {/* Step 3: Hackathon Mission Banner */}
        <motion.div variants={itemVariants} className="mt-8 p-6 rounded-[28px] bg-[#1c1b18] text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-editorial text-2xl font-light text-white">
                Empowering Frontline Responders Globally
              </h4>
              <p className="text-xs text-stone-400 mt-0.5">
                Leveraging NASA Open Science Data to minimize emergency latency from days to minutes.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="#hero-section"
              className="px-5 py-2.5 rounded-full bg-white text-black font-semibold text-xs tracking-wide hover:bg-stone-200 transition-colors flex items-center gap-2"
            >
              <span>Back to Global Map</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </motion.div>

      </motion.div>
    </section>
  );
};
