import React, { useState } from 'react';
import { 
  Search, 
  ArrowUpRight, 
  ArrowRight, 
  Play, 
  ChevronLeft, 
  ChevronRight, 
  Home, 
  LayoutGrid, 
  Users, 
  HeartHandshake, 
  Bookmark, 
  Radio, 
  ShieldAlert, 
  Compass, 
  Satellite, 
  Globe2, 
  Bell, 
  Layers, 
  Crosshair,
  Sparkles,
  Volume2
} from 'lucide-react';
import { DisasterZoneDetail } from '../data/disasterData';
import { InteractiveMap } from './InteractiveMap';

interface HeroSectionProps {
  zones: DisasterZoneDetail[];
  activeZoneIndex: number;
  onPrevZone: () => void;
  onNextZone: () => void;
  onSelectZone: (zone: DisasterZoneDetail) => void;
  onOpenVoiceAssistant: () => void;
  onOpenDemoShowreel: () => void;
  onNavigateSection: (sectionId: string) => void;
  selectionMode: boolean;
  onToggleSelectionMode: () => void;
  onStartAnalysis: () => void;
  onSearchClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  zones,
  activeZoneIndex,
  onPrevZone,
  onNextZone,
  onSelectZone,
  onOpenVoiceAssistant,
  onOpenDemoShowreel,
  onNavigateSection,
  selectionMode,
  onToggleSelectionMode,
  onStartAnalysis,
  onSearchClick
}) => {
  const [activeTab, setActiveTab] = useState<'Home' | 'Dashboard' | 'Community Reporting' | 'Resource Allocation' | 'About/Education'>('Home');
  const activeZone = zones[activeZoneIndex] || zones[0];

  const handleNavClick = (tabName: 'Home' | 'Dashboard' | 'Community Reporting' | 'Resource Allocation' | 'About/Education') => {
    setActiveTab(tabName);
    if (tabName === 'Home') onNavigateSection('hero-section');
    if (tabName === 'Dashboard') onNavigateSection('dashboard-section');
    if (tabName === 'Community Reporting') onNavigateSection('community-section');
    if (tabName === 'Resource Allocation') onNavigateSection('resources-section');
    if (tabName === 'About/Education') onNavigateSection('about-section');
  };

  return (
    <div id="hero-section" className="relative w-full max-w-[1480px] mx-auto px-2 sm:px-4 lg:px-6 pt-2 sm:pt-4 pb-8">
      {/* Outer Card Container matching the reference image's frame */}
      <div className="relative rounded-[32px] sm:rounded-[38px] bg-[#ede5dc] text-[#1c1b18] shadow-2xl border border-white/50 p-4 sm:p-6 md:p-7 overflow-hidden">
        
        {/* Subtle Ambient Background Gradient and Terrain Shading */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#f5ede4]/90 via-[#ede4da]/90 to-[#e3d8cd]/90 pointer-events-none -z-10" />

        {/* =========================================================================
            1. TOP BAR (Logo + Nav Pill + Search + CTA Button)
            ========================================================================= */}
        <header className="flex flex-col md:flex-row items-center justify-between gap-4 pb-4 md:pb-6 border-b border-[#ded3c6]/60">
          
          {/* Logo / Site Name */}
          <div className="flex items-center gap-3 self-start md:self-auto cursor-pointer" onClick={() => handleNavClick('Home')}>
            <div className="w-9 h-9 rounded-xl bg-[#1c1b18] text-white flex items-center justify-center font-bold text-sm tracking-tighter shadow-md">
              <span className="font-editorial text-lg italic pr-0.5">DR</span>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-xs sm:text-sm tracking-[0.18em] uppercase text-[#1c1b18] font-sans">
                DISASTER RISK MAPPING
              </span>
              <span className="text-[9px] tracking-[0.25em] uppercase text-[#736c64] font-tech font-semibold">
                NASA SPACE APPS HACKATHON
              </span>
            </div>
          </div>

          {/* Center Navigation Pill Container */}
          <nav className="flex items-center bg-[#e4dad0]/80 backdrop-blur-md rounded-full p-1 border border-white/60 shadow-xs overflow-x-auto max-w-full">
            {(['Home', 'Dashboard', 'Community Reporting', 'Resource Allocation', 'About/Education'] as const).map((tab) => {
              const isActive = activeTab === tab;
              return (
                <button
                  key={tab}
                  onClick={() => handleNavClick(tab)}
                  className={`whitespace-nowrap px-3.5 sm:px-5 py-2 rounded-full text-xs font-medium tracking-wide transition-all ${
                    isActive
                      ? 'bg-[#1c1b18] text-white shadow-xs'
                      : 'text-[#48433e] hover:text-black hover:bg-white/40'
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </nav>

          {/* Right Action Buttons: Search + Start Analysis CTA */}
          <div className="flex items-center gap-2.5 self-end md:self-auto">
            {/* Search Icon Button */}
            <button
              onClick={onSearchClick}
              aria-label="Search Disaster Areas"
              className="w-10 h-10 rounded-full bg-[#f6eee5] border border-white/70 shadow-xs flex items-center justify-center text-[#2b2723] hover:bg-white hover:scale-105 active:scale-95 transition-all"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* CTA Button: "Start Analysis" with white circle arrow */}
            <button
              onClick={onStartAnalysis}
              className="group bg-[#1c1b18] hover:bg-black text-white pl-5 pr-1.5 py-1.5 rounded-full flex items-center gap-3 font-medium text-xs tracking-wider transition-all shadow-md active:scale-95"
            >
              <span>Start Analysis</span>
              <div className="w-7 h-7 rounded-full bg-white text-[#1c1b18] flex items-center justify-center transition-transform group-hover:rotate-45">
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </div>
            </button>
          </div>
        </header>

        {/* =========================================================================
            HERO MAIN ROW: Left Vertical Icon Rail + Left Content + Right Interactive Map
            ========================================================================= */}
        <div className="relative pt-6 md:pt-8 flex flex-col lg:flex-row gap-6 md:gap-8 items-stretch">
          
          {/* =========================================================================
              2. LEFT VERTICAL ICON RAIL
              ========================================================================= */}
          <aside className="hidden md:flex flex-col items-center justify-between w-16 py-4 px-2 rounded-full bg-[#f8f3ed]/90 backdrop-blur-md border border-white/80 shadow-xl self-start shrink-0 z-20">
            {/* Top Navigation Icons */}
            <div className="flex flex-col items-center gap-3">
              {/* Home (Active dark circle) */}
              <button
                onClick={() => handleNavClick('Home')}
                aria-label="Home"
                className="w-10 h-10 rounded-full bg-[#1c1b18] text-white flex items-center justify-center shadow-xs hover:scale-105 transition-all"
              >
                <Home className="w-4 h-4" />
              </button>

              {/* Dashboard Icon */}
              <button
                onClick={() => handleNavClick('Dashboard')}
                aria-label="Disaster Dashboard"
                className="w-10 h-10 rounded-full text-[#524c45] hover:text-black hover:bg-white/70 flex items-center justify-center transition-all"
                title="Disaster Operations Dashboard"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>

              {/* Community Reporting Icon */}
              <button
                onClick={() => handleNavClick('Community Reporting')}
                aria-label="Community Ground Reports"
                className="w-10 h-10 rounded-full text-[#524c45] hover:text-black hover:bg-white/70 flex items-center justify-center transition-all"
                title="Community Reporting"
              >
                <Users className="w-4 h-4" />
              </button>

              {/* Resource Allocation Icon */}
              <button
                onClick={() => handleNavClick('Resource Allocation')}
                aria-label="Emergency Resource Allocation"
                className="w-10 h-10 rounded-full text-[#524c45] hover:text-black hover:bg-white/70 flex items-center justify-center transition-all"
                title="Emergency Resource Allocation"
              >
                <HeartHandshake className="w-4 h-4" />
              </button>

              {/* Saved Areas Icon */}
              <button
                onClick={() => onNavigateSection('dashboard-section')}
                aria-label="Saved Watchlist Areas"
                className="w-10 h-10 rounded-full text-[#524c45] hover:text-black hover:bg-white/70 flex items-center justify-center transition-all"
                title="Saved Disaster Watchlist"
              >
                <Bookmark className="w-4 h-4" />
              </button>

              {/* Small circular thumbnail preview (recent analyzed area) like reference photo circle */}
              <div 
                onClick={() => onSelectZone(activeZone)}
                title={`Recent Analyzed Area: ${activeZone.name}`}
                className="w-11 h-11 rounded-full overflow-hidden border-2 border-white shadow-md cursor-pointer hover:ring-2 hover:ring-amber-500 transition-all relative group"
              >
                <img
                  src={activeZone.imageUrl}
                  alt={activeZone.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <span className="absolute inset-0 bg-black/20 group-hover:bg-transparent" />
              </div>
            </div>

            {/* AI LIVE INDICATOR (at the bottom of this rail) */}
            <div className="flex flex-col items-center gap-1 pt-4 border-t border-[#ded3c6]/60 w-full">
              <button
                onClick={onOpenVoiceAssistant}
                aria-label="Open AI Voice Assistant"
                title="Open NASA AI Voice Assistant"
                className="relative w-11 h-11 rounded-full bg-[#1c1b18] text-amber-400 flex items-center justify-center shadow-lg group hover:scale-110 transition-all"
              >
                {/* Pulsing ring around AI Live icon */}
                <span className="absolute inline-flex h-full w-full rounded-full bg-amber-400/40 opacity-75 animate-ping"></span>
                <span className="relative flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                </span>
                {/* Active live dot */}
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-[#1c1b18]"></span>
              </button>
              <span className="text-[9px] font-tech font-bold uppercase tracking-wider text-[#635c55]">
                AI Live
              </span>
            </div>
          </aside>

          {/* =========================================================================
              3. HERO SECTION (Left Headline + Right Large Map)
              ========================================================================= */}
          <div className="flex-1 flex flex-col lg:flex-row gap-6 md:gap-8 items-stretch">
            
            {/* Left Column: Eyebrow + Headline + Description + Buttons */}
            <div className="w-full lg:w-[45%] flex flex-col justify-start pt-2 md:pt-4">
              
              {/* Eyebrow Label Row */}
              <div className="flex items-center gap-3 mb-4">
                <span className="text-[10px] sm:text-[11px] tracking-[0.28em] uppercase text-[#6d665f] font-semibold">
                  SATELLITE &nbsp;—&nbsp; AI &nbsp;—&nbsp; RESCUE MAPPING
                </span>
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              </div>

              {/* Big Editorial Headline */}
              <h1 className="font-editorial font-light text-5xl sm:text-6xl xl:text-7xl leading-[1.05] text-[#1c1b18] tracking-tight mb-4">
                Areas That <br />
                <span className="italic font-normal">Need You</span>
              </h1>

              {/* Short Description */}
              <p className="text-[#59524b] text-sm sm:text-[15px] leading-relaxed max-w-md mb-8">
                We harness high-resolution orbital Earth observation, SAR radar, and neural damage models to detect natural hazards, map vulnerable populations, and route emergency relief before seconds turn into casualties.
              </p>

              {/* Buttons: Primary "Select to Click" + Secondary "Watch Demo Analysis" */}
              <div className="flex flex-wrap items-center gap-3.5 mb-8">
                {/* Primary Button */}
                <button
                  onClick={onToggleSelectionMode}
                  className={`px-6 py-3.5 rounded-full font-medium text-xs tracking-wider flex items-center gap-2.5 shadow-lg transition-all active:scale-95 ${
                    selectionMode
                      ? 'bg-amber-500 text-black ring-4 ring-amber-400/30'
                      : 'bg-[#1c1b18] hover:bg-black text-white'
                  }`}
                >
                  <Crosshair className="w-4 h-4" />
                  <span>{selectionMode ? 'Click Map Enabled' : 'Select to Click'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                {/* Secondary Button */}
                <button
                  onClick={onOpenDemoShowreel}
                  className="border border-[#a59d93] hover:border-black text-[#1c1b18] px-5 py-3.5 rounded-full font-medium text-xs tracking-wider flex items-center gap-2.5 transition-all hover:bg-white/50 active:scale-95"
                >
                  <div className="w-6 h-6 rounded-full border border-current flex items-center justify-center">
                    <Play className="w-3 h-3 fill-current ml-0.5" />
                  </div>
                  <span>Watch Demo Analysis</span>
                </button>
              </div>

              {/* Quick Hazard Badges */}
              <div className="flex items-center gap-2 pt-2 text-[11px] text-[#787169] font-tech">
                <span className="font-semibold text-stone-700">ACTIVE MISSIONS:</span>
                <span className="bg-[#e4dad0] px-2.5 py-0.5 rounded-full text-stone-800">Sentinel-1 SAR</span>
                <span className="bg-[#e4dad0] px-2.5 py-0.5 rounded-full text-stone-800">SWOT Radar</span>
                <span className="bg-[#e4dad0] px-2.5 py-0.5 rounded-full text-stone-800">Landsat-9</span>
              </div>
            </div>

            {/* Right Column: Large Rounded Visual replaced with INTERACTIVE WORLD MAP */}
            <div className="w-full lg:w-[55%] relative flex flex-col justify-between">
              
              {/* Side Tag Labels (reference: "MODERN / SUSTAINABLE / FUNCTIONAL / TIMELESS") */}
              <div className="flex items-center justify-between pb-2 px-1">
                <div className="text-[10px] tracking-[0.2em] uppercase font-tech text-stone-500 font-semibold flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-500"></span>
                  <span>GLOBAL RADAR COVERAGE</span>
                </div>
                <div className="hidden sm:flex items-center gap-3 text-[9px] tracking-[0.22em] uppercase font-semibold text-[#6e6760] font-tech">
                  <span>REAL-TIME</span>
                  <span className="text-stone-400">/</span>
                  <span>AI-POWERED</span>
                  <span className="text-stone-400">/</span>
                  <span>SATELLITE-BASED</span>
                  <span className="text-stone-400">/</span>
                  <span>RELIABLE</span>
                </div>
              </div>

              {/* Interactive World Map Frame */}
              <div className="w-full h-[380px] sm:h-[410px] lg:h-[430px] rounded-[28px] sm:rounded-[34px] overflow-hidden shadow-2xl border border-white/60 relative">
                <InteractiveMap
                  zones={zones}
                  activeZone={activeZone}
                  onSelectZone={onSelectZone}
                  selectionMode={selectionMode}
                  onToggleSelectionMode={onToggleSelectionMode}
                />
              </div>
            </div>
          </div>
        </div>

        {/* =========================================================================
            BOTTOM CARDS ROW (Overlapping Floating Featured Card + Stats Row + Dark CTA Card)
            Matching the exact bottom composition of the reference image
            ========================================================================= */}
        <div className="relative pt-5 md:pt-6 grid grid-cols-1 md:grid-cols-12 gap-4 sm:gap-5 items-stretch">
          
          {/* =========================================================================
              4. FLOATING FEATURED CARD (Col 1-5 or Col 1-6)
              ========================================================================= */}
          <div className="md:col-span-6 lg:col-span-5 bg-white/95 backdrop-blur-md rounded-[32px] p-4 shadow-xl border border-white/80 flex flex-col sm:flex-row items-center gap-4 relative">
            
            {/* Left Thumbnail Image */}
            <div className="w-full sm:w-36 h-36 sm:h-28 rounded-[22px] overflow-hidden relative shrink-0 shadow-xs">
              <img
                src={activeZone.imageUrl}
                alt={activeZone.name}
                className="w-full h-full object-cover"
              />
              {/* Badge on top */}
              <div className="absolute top-2 left-2 bg-[#1c1b18]/85 backdrop-blur-xs text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-wider uppercase font-tech">
                FEATURED ZONE
              </div>

              {/* Responder team avatar stack */}
              <div className="absolute bottom-2 left-2 flex items-center -space-x-1.5 bg-black/60 backdrop-blur-xs p-1 rounded-full border border-white/20">
                <div className="w-5 h-5 rounded-full bg-emerald-500 border border-white text-[9px] text-white flex items-center justify-center font-bold">
                  ✓
                </div>
                <div className="w-5 h-5 rounded-full bg-blue-500 border border-white text-[9px] text-white flex items-center justify-center font-bold">
                  S
                </div>
                <div className="w-5 h-5 rounded-full bg-stone-800 border border-white text-[8px] text-white flex items-center justify-center font-bold">
                  +{activeZone.respondersOnSite}
                </div>
              </div>
            </div>

            {/* Middle Details & Bottom Controls */}
            <div className="flex-1 min-w-0 flex flex-col justify-between h-full py-0.5">
              
              {/* Top counter */}
              <div className="flex items-center justify-between text-[11px] text-[#736c64] font-tech font-semibold mb-1">
                <span className="uppercase text-amber-700 tracking-wider">
                  {activeZone.hazardType.toUpperCase()}
                </span>
                <span>
                  Live Area 0{activeZoneIndex + 1} / 0{zones.length}
                </span>
              </div>

              {/* Title & Caption */}
              <div>
                <h2 className="text-sm sm:text-base font-bold text-[#1c1b18] truncate">
                  {activeZone.name}
                </h2>
                <p className="text-[11px] text-[#5e5851] line-clamp-2 leading-snug mt-0.5">
                  {activeZone.summary}
                </p>
              </div>

              {/* Link: "View Damage Assessment ->" */}
              <button
                onClick={() => onNavigateSection('dashboard-section')}
                className="text-[11px] font-semibold text-[#1c1b18] hover:text-amber-700 flex items-center gap-1.5 mt-2 transition-colors self-start"
              >
                <span>View Damage Assessment</span>
                <ArrowRight className="w-3 h-3" />
              </button>

              {/* Bottom Dash indicators & Prev/Next Arrows */}
              <div className="flex items-center justify-between pt-2 border-t border-[#f0eae2] mt-2">
                {/* 6 Dashes Progress indicator */}
                <div className="flex items-center gap-1.5">
                  {zones.map((_, idx) => (
                    <div
                      key={idx}
                      onClick={() => onSelectZone(zones[idx])}
                      className={`h-1 rounded-full cursor-pointer transition-all ${
                        idx === activeZoneIndex
                          ? 'w-6 bg-[#1c1b18]'
                          : 'w-2.5 bg-[#d9cfc5] hover:bg-[#a89e93]'
                      }`}
                    />
                  ))}
                </div>

                {/* Prev / Next buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={onPrevZone}
                    aria-label="Previous Disaster Area"
                    className="w-8 h-8 rounded-full bg-[#f4ece3] hover:bg-[#1c1b18] hover:text-white text-[#2a2622] flex items-center justify-center transition-all active:scale-95"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={onNextZone}
                    aria-label="Next Disaster Area"
                    className="w-8 h-8 rounded-full bg-[#1c1b18] text-white hover:bg-black flex items-center justify-center transition-all active:scale-95 shadow-xs"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* =========================================================================
              5. STATS ROW (Col 6-9 or Col 7-9)
              ========================================================================= */}
          <div className="md:col-span-6 lg:col-span-4 bg-[#efe7df]/90 backdrop-blur-md rounded-[32px] p-5 sm:p-6 shadow-md border border-white/70 flex items-center justify-around gap-4 sm:gap-6">
            
            {/* Stat 1 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-white/60 flex items-center justify-center text-[#1c1b18] mb-2 shadow-2xs">
                <Satellite className="w-4 h-4" />
              </div>
              <span className="font-editorial text-2xl sm:text-3xl font-light text-[#1c1b18] tracking-tight">
                500+
              </span>
              <span className="text-[11px] font-medium text-[#6b645e] tracking-tight">
                Areas Tracked
              </span>
            </div>

            <div className="w-px h-12 bg-[#ded3c6]" />

            {/* Stat 2 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-white/60 flex items-center justify-center text-[#1c1b18] mb-2 shadow-2xs">
                <Bell className="w-4 h-4" />
              </div>
              <span className="font-editorial text-2xl sm:text-3xl font-light text-[#1c1b18] tracking-tight">
                50+
              </span>
              <span className="text-[11px] font-medium text-[#6b645e] tracking-tight">
                Alerts Generated
              </span>
            </div>

            <div className="w-px h-12 bg-[#ded3c6]" />

            {/* Stat 3 */}
            <div className="flex flex-col items-center text-center">
              <div className="w-8 h-8 rounded-full bg-white/60 flex items-center justify-center text-[#1c1b18] mb-2 shadow-2xs">
                <Globe2 className="w-4 h-4" />
              </div>
              <span className="font-editorial text-2xl sm:text-3xl font-light text-[#1c1b18] tracking-tight">
                15+
              </span>
              <span className="text-[11px] font-medium text-[#6b645e] tracking-tight">
                Countries Covered
              </span>
            </div>
          </div>

          {/* =========================================================================
              6. DARK CTA CARD (Col 10-12 or Col 9-12)
              ========================================================================= */}
          <div className="md:col-span-12 lg:col-span-3 bg-[#191917] text-white rounded-[32px] p-5 sm:p-6 shadow-2xl flex flex-col justify-between group cursor-pointer hover:bg-black transition-colors"
               onClick={() => onNavigateSection('dashboard-section')}
          >
            {/* Top row: Circular Photo Thumbnail + White Circular Arrow Button */}
            <div className="flex items-center justify-between pb-4">
              <div className="w-11 h-11 rounded-full overflow-hidden border border-white/20 shadow-md">
                <img
                  src="https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=400&q=80"
                  alt="Satellite Earth Scan"
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center shadow-lg group-hover:rotate-45 transition-transform">
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>

            {/* Bottom: Heading + Short Supporting Line */}
            <div>
              <h3 className="font-editorial text-xl sm:text-2xl font-light tracking-tight text-white mb-1.5 leading-snug">
                Be Ready Before Disaster Strikes
              </h3>
              <p className="text-[11px] text-stone-400 leading-relaxed font-sans">
                Predictive AI models and orbital telemetry to safeguard vulnerable communities in real time.
              </p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
