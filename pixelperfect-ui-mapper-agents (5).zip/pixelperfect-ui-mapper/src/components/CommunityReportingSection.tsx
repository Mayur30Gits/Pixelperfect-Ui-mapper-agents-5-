import React, { useEffect, useRef, useState } from 'react';
import { CommunityReport, CommunityReportKind, INITIAL_REPORTS } from '../data/disasterData';
import { 
  Users, 
  MapPin, 
  AlertTriangle, 
  Send, 
  CheckCircle2, 
  ThumbsUp, 
  Clock, 
  ShieldCheck, 
  Plus, 
  Camera, 
  Sparkles,
  X,
  Locate,
  Radio
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { postCommunityReport } from '../services/api';

const STORAGE_KEY = 'drm-community-reports-v1';
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024;
const VERIFY_THRESHOLD = 3;
const FEED_FILTERS = ['All', 'Alert', 'Damage', 'Photo'] as const;

const loadReports = (): CommunityReport[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    if (Array.isArray(parsed)) return parsed;
  } catch {
    // corrupted storage: fall back to seed data
  }
  return INITIAL_REPORTS;
};

const saveReports = (reports: CommunityReport[]): boolean => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    return true;
  } catch {
    return false; // quota exceeded (large photos)
  }
};

// Downscale photos so they fit in browser storage
const resizeImage = (file: File, maxSize = 1024): Promise<string> =>
  new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.round(img.width * scale);
      canvas.height = Math.round(img.height * scale);
      canvas.getContext('2d')?.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.72));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Unreadable image'));
    };
    img.src = url;
  });

const formatAge = (createdAt: number, now: number) => {
  const mins = Math.floor((now - createdAt) / 60000);
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  return new Date(createdAt).toLocaleDateString();
};

const isSafePhoto = (url?: string): url is string => !!url && url.startsWith('data:image/');

export const CommunityReportingSection: React.FC = () => {
  const [reports, setReports] = useState<CommunityReport[]>(loadReports);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [reportKind, setReportKind] = useState<CommunityReportKind>('Alert');
  const [locationName, setLocationName] = useState<string>('');
  const [hazardType, setHazardType] = useState<string>('Flash Flood Water Surge');
  const [severity, setSeverity] = useState<'Critical' | 'Severe' | 'Moderate' | 'Minor'>('Severe');
  const [reporterName, setReporterName] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [coords, setCoords] = useState<[number, number] | null>(null);
  const [formError, setFormError] = useState<string>('');
  const [isProcessingPhoto, setIsProcessingPhoto] = useState<boolean>(false);
  const [submittedSuccess, setSubmittedSuccess] = useState<boolean>(false);
  const [feedFilter, setFeedFilter] = useState<(typeof FEED_FILTERS)[number]>('All');
  const [now, setNow] = useState<number>(Date.now());
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Refresh relative timestamps
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 30000);
    return () => window.clearInterval(id);
  }, []);

  // Live sync between open tabs/windows
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY) setReports(loadReports());
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);

  const updateReports = (next: CommunityReport[]) => {
    setReports(next);
    if (!saveReports(next)) {
      setFormError('Browser storage is full — this report is visible now but may not persist after reload.');
    }
  };

  const handleVote = (id: string) => {
    updateReports(reports.map(r => r.id === id ? { ...r, votes: r.votes + 1 } : r));
  };

  const handlePhotoChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setFormError('Please choose an image file.');
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      setFormError('Photo is larger than 10 MB.');
      return;
    }
    setFormError('');
    setIsProcessingPhoto(true);
    try {
      setPhoto(await resizeImage(file));
    } catch {
      setFormError('Could not read that image.');
    } finally {
      setIsProcessingPhoto(false);
    }
  };

  const handleUseGps = () => {
    if (!('geolocation' in navigator)) {
      setFormError('Location is not available in this browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        setCoords([Number(pos.coords.latitude.toFixed(4)), Number(pos.coords.longitude.toFixed(4))]);
        setFormError('');
      },
      () => setFormError('Location permission denied.'),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const resetForm = () => {
    setLocationName('');
    setReporterName('');
    setNotes('');
    setPhoto(null);
    setCoords(null);
    setFormError('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!locationName.trim() || !notes.trim()) return;
    if (reportKind === 'Photo' && !photo) {
      setFormError('Attach a photo for a photo report.');
      return;
    }

    const newReport: CommunityReport = {
      id: `rep-${Date.now()}`,
      kind: reportKind,
      locationName: locationName.trim(),
      hazardType,
      severity,
      timestamp: 'Just now',
      createdAt: Date.now(),
      reporter: reporterName.trim() || 'Anonymous Volunteer',
      verified: false,
      notes: notes.trim(),
      coordinates: coords ?? undefined,
      photoUrl: photo ?? undefined,
      votes: 1
    };

    updateReports([newReport, ...reports]);
    postCommunityReport(newReport);
    resetForm();
    setShowForm(false);
    setFeedFilter('All');
    setSubmittedSuccess(true);
    setTimeout(() => setSubmittedSuccess(false), 4000);
  };

  const visibleReports = feedFilter === 'All'
    ? reports
    : reports.filter(r => (r.kind ?? (r.photoUrl ? 'Photo' : 'Alert')) === feedFilter);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: 'easeOut' as const }
    }
  };

  return (
    <section id="community-section" className="relative w-full max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.15 }}
        variants={containerVariants}
        className="rounded-[36px] bg-[#ece3d8] border border-white/60 p-6 sm:p-10 shadow-xl"
      >
        {/* Step 1: Section Header */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-[#ded2c3]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-tech font-bold">
                GROUND-TRUTHING NETWORK
              </span>
              <span className="w-2 h-2 rounded-full bg-amber-500" />
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl font-light text-[#1c1b18] tracking-tight">
              Community Ground Reporting
            </h2>
            <p className="text-stone-600 text-sm mt-2 max-w-xl">
              Fusing orbital radar passes with real-time ground truth. Community members, first responders, and local authorities submit verified alerts to calibrate satellite damage models.
            </p>
          </div>

          <button
            onClick={() => setShowForm(!showForm)}
            className="px-5 py-3 rounded-full bg-[#1c1b18] hover:bg-black text-white text-xs font-semibold tracking-wider flex items-center gap-2 shadow-md transition-all self-start md:self-auto active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{showForm ? 'Cancel Report' : 'Submit Field Report'}</span>
          </button>
        </motion.div>

        {submittedSuccess && (
          <div className="mt-4 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-800 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Field report logged successfully. Calibrating orbital boundary polygons and routing to local responders.</span>
          </div>
        )}

        {/* Form Drawer (if open) */}
        {showForm && (
          <motion.form
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            onSubmit={handleSubmit}
            className="mt-6 p-6 rounded-[28px] bg-white border border-stone-200 shadow-xl space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Submit Verified Ground Observation
              </h3>
              <span className="text-[11px] text-stone-500 font-tech">NASA GROUND LINK</span>
            </div>

            <div className="flex flex-wrap items-center gap-2" role="radiogroup" aria-label="Report type">
              {(['Alert', 'Damage', 'Photo'] as const).map(kind => (
                <button
                  key={kind}
                  type="button"
                  role="radio"
                  aria-checked={reportKind === kind}
                  onClick={() => setReportKind(kind)}
                  className={`px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                    reportKind === kind
                      ? 'bg-[#1c1b18] text-white border-[#1c1b18]'
                      : 'bg-white text-stone-600 border-stone-200 hover:border-stone-400'
                  }`}
                >
                  {kind === 'Alert' ? '⚠️ Alert' : kind === 'Damage' ? '🏚️ Damage Report' : '📷 Photo'}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Location / Specific Landmark *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Paiporta Southern Bridge, Valencia"
                  value={locationName}
                  onChange={e => setLocationName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-amber-500/30 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Hazard Classification *
                </label>
                <select
                  value={hazardType}
                  onChange={e => setHazardType(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-amber-500/30 focus:outline-none"
                >
                  <option value="Flash Flood Water Surge">Flash Flood Water Surge</option>
                  <option value="Wildfire Perimeter & Heavy Smoke">Wildfire Perimeter & Heavy Smoke</option>
                  <option value="Structural Rupture & Road Obstruction">Structural Rupture & Road Obstruction</option>
                  <option value="Storm Surge Embankment Breach">Storm Surge Embankment Breach</option>
                  <option value="Medical Access Compromised">Medical Access Compromised</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Observed Severity Level *
                </label>
                <select
                  value={severity}
                  onChange={e => setSeverity(e.target.value as any)}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-amber-500/30 focus:outline-none"
                >
                  <option value="Critical">Critical (Immediate life hazard)</option>
                  <option value="Severe">Severe (Major structural/transit loss)</option>
                  <option value="Moderate">Moderate (Restricted access)</option>
                  <option value="Minor">Minor (Monitored)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Reporter / Organization
                </label>
                <input
                  type="text"
                  placeholder="e.g. Maria G. (Red Cross Volunteer)"
                  value={reporterName}
                  onChange={e => setReporterName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-amber-500/30 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                Detailed Field Observations & Needs *
              </label>
              <textarea
                required
                rows={3}
                placeholder="Describe current water depth, road passability, vulnerable individuals, or urgent medical / supply needs..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl border border-stone-200 text-xs focus:ring-2 focus:ring-amber-500/30 focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap items-start gap-4">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoChange}
                className="hidden"
              />
              {photo ? (
                <div className="relative w-32 h-24 rounded-xl overflow-hidden border border-stone-200 shadow-sm">
                  <img src={photo} alt="Report attachment preview" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setPhoto(null)}
                    aria-label="Remove photo"
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 text-white flex items-center justify-center"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingPhoto}
                  className="w-32 h-24 rounded-xl border-2 border-dashed border-stone-300 hover:border-amber-500 text-stone-500 hover:text-amber-700 text-[11px] font-semibold flex flex-col items-center justify-center gap-1 transition-colors disabled:opacity-60"
                >
                  <Camera className="w-5 h-5" />
                  {isProcessingPhoto ? 'Processing…' : reportKind === 'Photo' ? 'Add photo *' : 'Add photo'}
                </button>
              )}

              <button
                type="button"
                onClick={handleUseGps}
                className={`px-4 py-2 rounded-full text-xs font-semibold border flex items-center gap-1.5 transition-colors ${
                  coords
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                    : 'bg-white border-stone-200 text-stone-700 hover:border-stone-400'
                }`}
              >
                <Locate className="w-3.5 h-3.5" />
                {coords ? `GPS ${coords[0]}, ${coords[1]}` : 'Tag my GPS location'}
              </button>
            </div>

            {formError && (
              <p className="text-[11px] text-rose-600 font-medium">{formError}</p>
            )}

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2 text-[11px] text-stone-500">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
                <span>Reports show as pending until {VERIFY_THRESHOLD} people confirm them</span>
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs flex items-center gap-2 shadow-md transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Transmit Field Report</span>
              </button>
            </div>
          </motion.form>
        )}

        {/* Step 2: Live Report Feed */}
        <motion.div variants={itemVariants} className="pt-8 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-stone-800">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500" />
            </span>
            <Radio className="w-4 h-4 text-stone-500" />
            <span className="tracking-wider uppercase font-tech">Live Feed</span>
            <span className="text-stone-500 font-normal">· {reports.length} reports</span>
          </div>
          <div className="flex items-center gap-1 bg-white/70 p-1 rounded-full border border-white">
            {FEED_FILTERS.map(f => (
              <button
                key={f}
                onClick={() => setFeedFilter(f)}
                className={`px-3.5 py-1 rounded-full text-[11px] font-semibold transition-all ${
                  feedFilter === f ? 'bg-[#1c1b18] text-white' : 'text-stone-600 hover:text-black'
                }`}
              >
                {f === 'All' ? 'All' : `${f}s`}
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-5">
          {visibleReports.length === 0 && (
            <p className="text-xs text-stone-500 col-span-full">No {feedFilter.toLowerCase()} reports yet.</p>
          )}
          <AnimatePresence initial={false}>
          {visibleReports.map((report) => {
            const isVerified = report.verified || report.votes >= VERIFY_THRESHOLD;
            return (
            <motion.div
              key={report.id}
              layout
              initial={{ opacity: 0, y: -16, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="bg-white/95 rounded-[24px] p-5 border border-white/80 shadow-md hover:shadow-lg transition-shadow flex flex-col justify-between"
            >
              <div>
                {isSafePhoto(report.photoUrl) && (
                  <img
                    src={report.photoUrl}
                    alt={`Field photo: ${report.locationName}`}
                    className="w-full h-48 object-cover rounded-2xl mb-3 border border-stone-100"
                    loading="lazy"
                  />
                )}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-xs font-bold text-stone-800 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-stone-400" />
                      {report.locationName}
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full font-tech uppercase ${
                    report.severity === 'Critical' 
                      ? 'bg-rose-500/10 text-rose-600 border border-rose-500/20'
                      : 'bg-amber-500/10 text-amber-700 border border-amber-500/20'
                  }`}>
                    {report.severity}
                  </span>
                </div>

                <div className="text-[11px] font-semibold text-stone-600 mb-1.5 flex flex-wrap items-center gap-2">
                  {report.kind && (
                    <span className="bg-[#1c1b18] text-white px-2 py-0.5 rounded text-[10px] uppercase tracking-wider">
                      {report.kind}
                    </span>
                  )}
                  <span className="bg-stone-100 px-2 py-0.5 rounded text-stone-700">
                    {report.hazardType}
                  </span>
                  <span className="text-stone-400">•</span>
                  <span className="text-stone-500 flex items-center gap-1 font-tech">
                    <Clock className="w-3 h-3" />
                    {report.createdAt ? formatAge(report.createdAt, now) : report.timestamp}
                  </span>
                  {report.coordinates && (
                    <span className="text-stone-400 font-tech">
                      {report.coordinates[0]}, {report.coordinates[1]}
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-700 leading-relaxed bg-[#fbf9f6] p-3 rounded-xl border border-stone-100">
                  "{report.notes}"
                </p>
              </div>

              <div className="pt-3 mt-3 border-t border-stone-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-stone-500 text-[11px]">
                  <ShieldCheck className={`w-3.5 h-3.5 ${isVerified ? 'text-emerald-600' : 'text-stone-400'}`} />
                  <span>By <strong className="text-stone-700">{report.reporter}</strong></span>
                  {!isVerified && (
                    <span className="text-[10px] text-amber-700 bg-amber-500/10 px-1.5 py-0.5 rounded">Pending</span>
                  )}
                </div>

                <button
                  onClick={() => handleVote(report.id)}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold transition-colors active:scale-95"
                >
                  <ThumbsUp className="w-3 h-3 text-stone-500" />
                  <span>{isVerified ? 'Verified' : 'Confirm'} ({report.votes})</span>
                </button>
              </div>
            </motion.div>
            );
          })}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    </section>
  );
};
