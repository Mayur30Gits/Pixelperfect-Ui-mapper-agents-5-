import React, { useEffect, useRef, useState } from 'react';
import { DisasterZoneDetail } from '../data/disasterData';
import { 
  NASA_API_KEY, 
  NASA_GIBS_TILE_URLS, 
  fetchNasaLiveEvents, 
  NasaLiveEvent 
} from '../services/nasaService';
import { 
  findNearestDisasterZone, 
  calculateDistanceKm 
} from '../utils/disasterCalculations';
import { 
  Layers, 
  Crosshair, 
  ZoomIn, 
  ZoomOut, 
  Compass, 
  Radio, 
  Satellite, 
  ShieldAlert, 
  Activity, 
  CheckCircle2, 
  Maximize2,
  Sparkles,
  Flame,
  Moon,
  Info,
  Key,
  Locate,
  MapPin
} from 'lucide-react';
import L from 'leaflet';
import { analyzeLocationApi } from '../services/api';
import { MAP_COMMAND_EVENT, MapCommand } from '../ai/uiActions';

interface InteractiveMapProps {
  zones: DisasterZoneDetail[];
  activeZone: DisasterZoneDetail;
  onSelectZone: (zone: DisasterZoneDetail) => void;
  selectionMode: boolean;
  onToggleSelectionMode: () => void;
  onCustomLocationSelected?: (coords: [number, number], name: string) => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  zones,
  activeZone,
  onSelectZone,
  selectionMode,
  onToggleSelectionMode,
  onCustomLocationSelected
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const circlesRef = useRef<L.Circle[]>([]);
  const nasaMarkersRef = useRef<L.Marker[]>([]);
  const fireLayerRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  const [activeLayer, setActiveLayer] = useState<'satellite' | 'nasaViirs' | 'nasaFires' | 'nasaNight' | 'sar'>('satellite');
  const [cursorCoords, setCursorCoords] = useState<string>('39.4699° N, 0.3763° W');
  const [satellitePassProgress, setSatellitePassProgress] = useState<number>(72);
  const [liveNasaEvents, setLiveNasaEvents] = useState<NasaLiveEvent[]>([]);
  const [showNasaEvents, setShowNasaEvents] = useState<boolean>(true);
  const [selectedNasaEvent, setSelectedNasaEvent] = useState<NasaLiveEvent | null>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [nearestZoneInfo, setNearestZoneInfo] = useState<{ name: string; distKm: number } | null>(null);
  const [locationStatus, setLocationStatus] = useState<string>('Detecting location...');
  const [analysisResult, setAnalysisResult] = useState<{
    coords: [number, number];
    severity: string;
    hazard: string;
    score: number;
  } | null>(null);
  const [layerStatus, setLayerStatus] = useState<string>('');
  const [fireEvents, setFireEvents] = useState<NasaLiveEvent[] | null>(null);

  const tileLayerRef = useRef<L.TileLayer | null>(null);

  // Map analysis: asks the backend (nearest tracked zone + live NASA events) instead of random numbers
  const analyzeAt = async (lat: number, lng: number) => {
    try {
      const a = await analyzeLocationApi(lat, lng);
      const nearestEvent = a.nearbyLiveEvents[0];
      setAnalysisResult({
        coords: [lat, lng],
        severity: a.risk?.tier ?? 'No tracked hazard',
        hazard: a.withinTrackedZone
          ? a.nearestZone.name
          : nearestEvent
            ? `${nearestEvent.title} (${nearestEvent.distanceKm} km away)`
            : 'No active NASA hazard nearby',
        score: a.risk?.score ?? 0
      });
    } catch {
      setAnalysisResult({ coords: [lat, lng], severity: 'Unavailable', hazard: 'Analysis service unreachable', score: 0 });
    }
  };

  // Map layer configurations including NASA GIBS Earthdata tiles.
  // NASA Fires uses satellite imagery as the base and draws live EONET wildfire points on top.
  const tileLayers = {
    satellite: NASA_GIBS_TILE_URLS.highRes,
    nasaViirs: NASA_GIBS_TILE_URLS.nasaViirsTrueColor,
    nasaFires: NASA_GIBS_TILE_URLS.highRes,
    nasaNight: NASA_GIBS_TILE_URLS.nasaNightLights,
    sar: NASA_GIBS_TILE_URLS.sarRadar
  };

  // Highest zoom level each NASA GIBS layer actually serves; Leaflet upscales beyond it.
  const nativeMaxZoom: Partial<Record<keyof typeof tileLayers, number>> = {
    nasaViirs: 9,
    nasaNight: 8
  };

  const createTileLayer = (layerKey: keyof typeof tileLayers) => {
    const isGibs = layerKey === 'nasaNight' || layerKey === 'nasaViirs';
    const createdLayer = L.tileLayer(tileLayers[layerKey], {
      maxZoom: 18,
      maxNativeZoom: nativeMaxZoom[layerKey] ?? 18,
      // GIBS sends CORS headers; CORS-mode image requests load where plain no-cors requests get blocked
      crossOrigin: isGibs ? 'anonymous' : undefined
    });

    if (isGibs) {
      createdLayer.on('tileerror', () => {
        setLayerStatus('Some NASA tiles failed to load for this area.');
      });
    }

    return createdLayer;
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    try {
      const map = L.map(mapContainerRef.current, {
        center: activeZone.coordinates,
        zoom: 5,
        zoomControl: false,
        attributionControl: false
      });

      // Default satellite tile layer
      tileLayerRef.current = L.tileLayer(tileLayers.satellite, {
        maxZoom: 18,
        attribution: 'NASA GIBS & Earth Observation'
      }).addTo(map);

      map.on('mousemove', (e: L.LeafletMouseEvent) => {
        const lat = e.latlng.lat;
        const lng = e.latlng.lng;
        const latDir = lat >= 0 ? 'N' : 'S';
        const lngDir = lng >= 0 ? 'E' : 'W';
        setCursorCoords(`${Math.abs(lat).toFixed(4)}° ${latDir}, ${Math.abs(lng).toFixed(4)}° ${lngDir}`);
      });

      map.on('click', (e: L.LeafletMouseEvent) => {
        const lat = Number(e.latlng.lat.toFixed(4));
        const lng = Number(e.latlng.lng.toFixed(4));
        
        analyzeAt(lat, lng);

        if (onCustomLocationSelected) {
          onCustomLocationSelected([lat, lng], `Grid [${lat}, ${lng}]`);
        }
      });

      mapInstanceRef.current = map;
    } catch (err) {
      console.warn('Map initialization:', err);
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Commands from the AI assistant: fly to a place, switch layer, run analysis
  useEffect(() => {
    const onCommand = (e: Event) => {
      const cmd = (e as CustomEvent<MapCommand>).detail;
      const map = mapInstanceRef.current;
      if (!cmd || !map) return;
      if (cmd.type === 'setLayer') {
        setActiveLayer(cmd.layer);
      } else if (Number.isFinite(cmd.lat) && Number.isFinite(cmd.lng)) {
        map.flyTo([cmd.lat, cmd.lng], cmd.type === 'flyTo' ? cmd.zoom ?? 7 : 7, { duration: 1.2 });
        if (cmd.type === 'analyze') analyzeAt(cmd.lat, cmd.lng);
      }
    };
    window.addEventListener(MAP_COMMAND_EVENT, onCommand);
    return () => window.removeEventListener(MAP_COMMAND_EVENT, onCommand);
  }, []);

  // Fetch live NASA EONET events
  useEffect(() => {
    fetchNasaLiveEvents(8).then(events => {
      if (events && events.length > 0) {
        setLiveNasaEvents(events);
      }
    });
  }, []);

  // Switch Layer
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    setLayerStatus('');

    if (tileLayerRef.current) {
      mapInstanceRef.current.removeLayer(tileLayerRef.current);
    }

    tileLayerRef.current = createTileLayer(activeLayer).addTo(mapInstanceRef.current);
  }, [activeLayer]);

  // Load NASA EONET open wildfires the first time the Fires layer is selected
  useEffect(() => {
    if (activeLayer !== 'nasaFires' || fireEvents !== null) return;
    setLayerStatus('Loading live NASA wildfire detections…');
    fetchNasaLiveEvents(500, 'wildfires').then(events => {
      setFireEvents(events);
    });
  }, [activeLayer, fireEvents]);

  // Draw / remove wildfire points for the Fires layer
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    fireLayerRef.current?.remove();
    fireLayerRef.current = null;

    if (activeLayer !== 'nasaFires' || fireEvents === null) return;

    if (fireEvents.length === 0) {
      setLayerStatus('NASA wildfire feed is unreachable right now.');
      return;
    }

    const group = L.layerGroup();
    fireEvents.forEach(ev => {
      const popup = document.createElement('div');
      popup.style.cssText = 'font-family: system-ui; font-size: 11px;';
      const title = document.createElement('strong');
      title.textContent = ev.title;
      const meta = document.createElement('div');
      meta.textContent = `Last update: ${ev.date} · Source: ${ev.source}`;
      popup.append(title, meta);

      L.circleMarker(ev.coordinates, {
        radius: 5,
        color: '#fff7ed',
        weight: 1,
        fillColor: '#f97316',
        fillOpacity: 0.9
      }).bindPopup(popup).addTo(group);
    });
    group.addTo(map);
    fireLayerRef.current = group;
    setLayerStatus(`${fireEvents.length} active wildfires · NASA EONET`);

    // If no detections are in view, fly to where they are
    const bounds = map.getBounds();
    if (!fireEvents.some(ev => bounds.contains(ev.coordinates))) {
      map.flyToBounds(L.latLngBounds(fireEvents.map(ev => ev.coordinates)), { padding: [30, 30], maxZoom: 6, duration: 1.2 });
    }
  }, [activeLayer, fireEvents]);

  // Update Disaster Zone Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];
    circlesRef.current.forEach(c => c.remove());
    circlesRef.current = [];

    zones.forEach(zone => {
      const isCurrent = zone.id === activeZone.id;
      const color = zone.hazardType === 'flood' ? '#38bdf8' 
                  : zone.hazardType === 'wildfire' ? '#f97316' 
                  : zone.hazardType === 'earthquake' ? '#ef4444' 
                  : zone.hazardType === 'cyclone' ? '#a855f7' 
                  : '#eab308';

      const circle = L.circle(zone.coordinates, {
        color: color,
        fillColor: color,
        fillOpacity: isCurrent ? 0.35 : 0.15,
        radius: isCurrent ? 45000 : 25000,
        weight: isCurrent ? 2 : 1
      }).addTo(map);
      circlesRef.current.push(circle);

      const customIcon = L.divIcon({
        className: 'custom-hazard-marker',
        html: `
          <div class="relative flex items-center justify-center group cursor-pointer" style="transform: translate(-50%, -50%);">
            <div class="w-10 h-10 rounded-full flex items-center justify-center ${isCurrent ? 'scale-110' : 'scale-90'} transition-transform duration-300">
              <span class="absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping" style="background-color: ${color};"></span>
              <div class="relative w-8 h-8 rounded-full border-2 border-white shadow-xl flex items-center justify-center text-white text-xs font-bold" style="background-color: ${color};">
                ${zone.hazardType === 'flood' ? '🌊' : zone.hazardType === 'wildfire' ? '🔥' : zone.hazardType === 'earthquake' ? '⚡' : '🌀'}
              </div>
            </div>
            ${isCurrent ? `
              <div class="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black/90 text-white text-[10px] font-semibold px-2.5 py-0.5 rounded-full border border-white/20 shadow-lg tracking-wider">
                ${zone.name.split(' ')[0]}
              </div>
            ` : ''}
          </div>
        `,
        iconSize: [40, 40],
        iconAnchor: [20, 20]
      });

      const marker = L.marker(zone.coordinates, { icon: customIcon }).addTo(map);
      marker.on('click', () => {
        onSelectZone(zone);
      });
      markersRef.current.push(marker);
    });
  }, [zones, activeZone]);

  // Render NASA EONET Live Satellite Pins
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    nasaMarkersRef.current.forEach(m => m.remove());
    nasaMarkersRef.current = [];

    if (!showNasaEvents) return;

    liveNasaEvents.forEach(ev => {
      const isFire = ev.category.toLowerCase().includes('fire');
      const isStorm = ev.category.toLowerCase().includes('storm') || ev.category.toLowerCase().includes('cyclone');
      const pinColor = isFire ? '#fb923c' : isStorm ? '#818cf8' : '#34d399';

      const nasaIcon = L.divIcon({
        className: 'nasa-eonet-marker',
        html: `
          <div class="relative flex items-center justify-center cursor-pointer" style="transform: translate(-50%, -50%);">
            <div class="w-6 h-6 rounded-full border border-white/80 shadow-md flex items-center justify-center text-[10px]" style="background-color: ${pinColor};">
              ${isFire ? '🔥' : isStorm ? '🌀' : '🛰️'}
            </div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      const marker = L.marker(ev.coordinates, { icon: nasaIcon }).addTo(map);
      marker.on('click', () => {
        setSelectedNasaEvent(ev);
      });
      nasaMarkersRef.current.push(marker);
    });
  }, [liveNasaEvents, showNasaEvents]);

  // Center on Active Zone change
  useEffect(() => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo(activeZone.coordinates, 6, {
        animate: true,
        duration: 1.2
      });
    }
  }, [activeZone]);

  // Automatic geolocation and recentering to user location
  const locateAndRecenter = (isAuto: boolean = false) => {
    if (!('geolocation' in navigator)) {
      setLocationStatus('Geolocation unsupported');
      return;
    }

    setIsLocating(true);
    setLocationStatus('Acquiring GPS coordinates...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(4));
        const lng = Number(pos.coords.longitude.toFixed(4));
        setUserLocation([lat, lng]);
        setIsLocating(false);
        setLocationStatus(`Observer Located: ${lat}°, ${lng}°`);

        // Find nearest disaster zone
        const nearest = findNearestDisasterZone(lat, lng, zones);
        if (nearest) {
          setNearestZoneInfo({
            name: nearest.zone.name,
            distKm: nearest.distanceKm
          });
        }

        // Recenter map smoothly to user location
        const map = mapInstanceRef.current;
        if (map) {
          map.flyTo([lat, lng], 8, {
            animate: true,
            duration: 1.5
          });

          // Render / update user marker
          if (userMarkerRef.current) {
            userMarkerRef.current.remove();
          }

          const userIcon = L.divIcon({
            className: 'user-observer-marker',
            html: `
              <div class="relative flex items-center justify-center cursor-pointer" style="transform: translate(-50%, -50%);">
                <span class="absolute inline-flex h-12 w-12 rounded-full bg-cyan-400 opacity-75 animate-ping"></span>
                <div class="relative w-8 h-8 rounded-full border-2 border-white shadow-2xl bg-cyan-500 flex items-center justify-center text-white text-xs font-bold ring-4 ring-cyan-400/40">
                  📍
                </div>
                <div class="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-cyan-950/90 text-cyan-200 text-[10px] font-bold px-2 py-0.5 rounded-full border border-cyan-400/30 shadow-lg tracking-wider font-tech">
                  YOU ARE HERE
                </div>
              </div>
            `,
            iconSize: [36, 36],
            iconAnchor: [18, 18]
          });

          const uMarker = L.marker([lat, lng], { icon: userIcon }).addTo(map);
          uMarker.bindPopup(`
            <div style="font-family: system-ui; font-size: 11px; padding: 4px;">
              <strong style="color: #06b6d4;">🛰️ YOUR LOCATION</strong><br/>
              Coordinates: ${lat}°, ${lng}°<br/>
              ${nearest ? `Nearest Hazard: <strong>${nearest.zone.name}</strong> (${nearest.distanceKm} km away)` : ''}
            </div>
          `);
          userMarkerRef.current = uMarker;
        }
      },
      (err) => {
        console.warn('Geolocation access:', err.message);
        setIsLocating(false);
        setLocationStatus('GPS default (Valencia active)');
        // Fall back gracefully
        if (!isAuto && mapInstanceRef.current) {
          mapInstanceRef.current.flyTo(activeZone.coordinates, 6, { duration: 1.2 });
        }
      },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }
    );
  };

  // Automatically recenter on user location on component mount
  useEffect(() => {
    locateAndRecenter(true);
  }, []);

  const handleZoomIn = () => mapInstanceRef.current?.zoomIn();
  const handleZoomOut = () => mapInstanceRef.current?.zoomOut();
  const handleResetView = () => mapInstanceRef.current?.flyTo([20, 0], 2, { duration: 1 });

  return (
    <div className="relative w-full h-full min-h-[380px] rounded-[28px] sm:rounded-[34px] overflow-hidden select-none bg-stone-900">
      {/* Actual Leaflet Map Canvas */}
      <div 
        ref={mapContainerRef} 
        className="w-full h-full z-0 cursor-crosshair"
        data-testid="interactive-map-canvas"
        style={{ background: '#0e141b' }}
      />

      {/* Top Left: NASA API Telemetry HUD Badge */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1 pointer-events-auto">
        <div className="flex items-center gap-2 bg-[#121417]/90 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/15 shadow-xl text-white">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-[10px] sm:text-[11px] font-semibold tracking-wider uppercase font-tech text-emerald-400">
            {activeZone.satelliteMission}
          </span>
        </div>

        {/* NASA API Key status pill */}
        <div className="bg-[#121417]/85 backdrop-blur-md px-2.5 py-1 rounded-md border border-amber-500/30 text-[9px] sm:text-[10px] text-stone-200 font-tech flex items-center gap-1.5 shadow-md">
          <Key className="w-3 h-3 text-amber-400" />
          <span className="text-amber-300 font-bold">NASA API KEY:</span>
          <span className="text-stone-300 font-mono">
            {NASA_API_KEY.substring(0, 8)}...{NASA_API_KEY.substring(NASA_API_KEY.length - 4)}
          </span>
          <span className="bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded text-[8px] font-bold">
            VALIDATED
          </span>
        </div>
      </div>

      {/* Top Right: NASA GIBS Tile Layer Switcher & Mode Indicator */}
      <div className="absolute top-3 right-3 z-10 flex flex-wrap items-center justify-end gap-1.5 pointer-events-auto max-w-[85%] sm:max-w-none">
        <div className="bg-[#121417]/90 backdrop-blur-md p-1 rounded-full border border-white/15 shadow-xl flex items-center gap-1 text-[10px] sm:text-[11px]">
          <button
            onClick={() => setActiveLayer('satellite')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              activeLayer === 'satellite' 
                ? 'bg-white text-black shadow-xs font-semibold' 
                : 'text-stone-300 hover:text-white'
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => setActiveLayer('nasaViirs')}
            title="NASA VIIRS SNPP True Color Reflectance"
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              activeLayer === 'nasaViirs' 
                ? 'bg-cyan-400 text-black shadow-xs font-semibold' 
                : 'text-stone-300 hover:text-white'
            }`}
          >
            NASA VIIRS
          </button>
          <button
            onClick={() => setActiveLayer('nasaFires')}
            title="Live NASA EONET wildfire detections"
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              activeLayer === 'nasaFires' 
                ? 'bg-orange-500 text-white shadow-xs font-semibold' 
                : 'text-stone-300 hover:text-white'
            }`}
          >
            NASA Fires
          </button>
          <button
            onClick={() => setActiveLayer('nasaNight')}
            title="NASA Black Marble Nighttime Lights & Outages"
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              activeLayer === 'nasaNight' 
                ? 'bg-indigo-500 text-white shadow-xs font-semibold' 
                : 'text-stone-300 hover:text-white'
            }`}
          >
            Night Lights
          </button>
          <button
            onClick={() => setActiveLayer('sar')}
            className={`px-2.5 py-1 rounded-full font-medium transition-all ${
              activeLayer === 'sar' 
                ? 'bg-amber-400 text-black shadow-xs font-semibold' 
                : 'text-stone-300 hover:text-white'
            }`}
          >
            SAR
          </button>
        </div>

        {layerStatus && (
          <div className="bg-[#101417]/90 text-[10px] text-amber-200 border border-amber-400/30 px-2.5 py-1 rounded-full shadow-lg">
            {layerStatus}
          </div>
        )}

        {/* Selection mode indicator badge */}
        <button
          onClick={onToggleSelectionMode}
          title="Toggle Click-to-Select Map Mode"
          className={`px-2.5 sm:px-3 py-1 rounded-full text-[10px] sm:text-xs font-semibold flex items-center gap-1.5 shadow-lg transition-all border ${
            selectionMode 
              ? 'bg-amber-500 text-black border-amber-300 ring-2 ring-amber-400/50' 
              : 'bg-[#181a1e]/90 text-stone-300 border-white/15 hover:bg-stone-800'
          }`}
        >
          <Crosshair className={`w-3.5 h-3.5 ${selectionMode ? 'animate-spin' : ''}`} />
          <span>{selectionMode ? 'Grid Active' : 'Select'}</span>
        </button>
      </div>

      {/* Floating Click Analysis Result Modal (if user clicks on map) */}
      {analysisResult && (
        <div className="absolute top-16 left-3 right-3 sm:right-auto sm:w-80 z-20 bg-[#161a20]/95 backdrop-blur-xl border border-amber-500/40 rounded-2xl p-3.5 shadow-2xl text-white animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-amber-400 tracking-wide font-tech">NASA SURFACE SCAN ANALYZED</span>
            </div>
            <button 
              onClick={() => setAnalysisResult(null)} 
              className="text-stone-400 hover:text-white text-xs px-1.5 py-0.5 rounded bg-white/5"
            >
              ✕
            </button>
          </div>
          <div className="pt-2 text-xs space-y-1.5">
            <div className="flex justify-between">
              <span className="text-stone-400">Target Coords:</span>
              <span className="font-tech font-medium text-emerald-400">
                {analysisResult.coords[0]}°, {analysisResult.coords[1]}°
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-400">Satellite Sensor:</span>
              <span className="font-medium text-white">{analysisResult.hazard}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-stone-400">Hazard Score:</span>
              <span className="font-bold text-xs text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30">
                {analysisResult.score}/100 ({analysisResult.severity})
              </span>
            </div>
            <div className="pt-1 text-[11px] text-stone-300 bg-black/40 p-2 rounded-lg border border-white/5 leading-snug">
              NASA GIBS backscatter & active thermal differential processed via API key credentials.
            </div>
          </div>
        </div>
      )}

      {/* Selected NASA Live EONET Event Info Modal */}
      {selectedNasaEvent && (
        <div className="absolute top-16 left-3 right-3 sm:right-auto sm:w-80 z-20 bg-[#121417]/95 backdrop-blur-xl border border-cyan-400/50 rounded-2xl p-3.5 shadow-2xl text-white animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <div className="flex items-center gap-1.5">
              <Satellite className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-cyan-300 font-tech">LIVE NASA EONET EVENT</span>
            </div>
            <button 
              onClick={() => setSelectedNasaEvent(null)} 
              className="text-stone-400 hover:text-white text-xs px-1.5 py-0.5 rounded bg-white/5"
            >
              ✕
            </button>
          </div>
          <div className="pt-2 text-xs space-y-1">
            <div className="font-bold text-white text-sm">{selectedNasaEvent.title}</div>
            <div className="text-stone-400 text-[11px] flex justify-between">
              <span>Category: <strong className="text-stone-200">{selectedNasaEvent.category}</strong></span>
              <span>Date: <strong className="text-stone-200">{selectedNasaEvent.date}</strong></span>
            </div>
            <div className="text-[11px] text-stone-400">
              Source: <span className="font-tech text-cyan-400">{selectedNasaEvent.source}</span>
            </div>
            <div className="text-[11px] text-stone-300 pt-1">
              Location: <span className="font-tech text-emerald-400">{selectedNasaEvent.coordinates[0]}° N, {selectedNasaEvent.coordinates[1]}° E</span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Center: Coordinates & Orbit Pass HUD */}
      <div className="absolute bottom-3 left-3 z-10 pointer-events-auto flex flex-col md:flex-row items-start md:items-center gap-2">
        <div className="bg-[#121417]/85 backdrop-blur-md px-3 py-1 rounded-full border border-white/15 text-[10px] sm:text-[11px] text-stone-200 font-tech flex items-center gap-2 shadow-lg">
          <Compass className="w-3 h-3 text-amber-400 animate-pulse" />
          <span>{cursorCoords}</span>
        </div>

        <div className="bg-[#121417]/85 backdrop-blur-md px-3 py-1 rounded-full border border-white/15 text-[9px] sm:text-[10px] text-stone-300 font-tech flex items-center gap-2 shadow-lg">
          <span>NASA ORBIT PASS</span>
          <div className="w-14 h-1.5 bg-stone-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-1000"
              style={{ width: `${satellitePassProgress}%` }}
            />
          </div>
          <span className="text-emerald-400 font-bold">{satellitePassProgress}%</span>
        </div>
      </div>

      {/* Bottom Right: Map Zoom & Reset Controls */}
      <div className="absolute bottom-3 right-3 z-10 flex flex-col gap-1.5 pointer-events-auto">
        <button
          onClick={handleZoomIn}
          title="Zoom In"
          aria-label="Zoom In"
          className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#161a20]/90 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg hover:bg-stone-700 active:scale-95 transition-all"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={handleZoomOut}
          title="Zoom Out"
          aria-label="Zoom Out"
          className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#161a20]/90 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg hover:bg-stone-700 active:scale-95 transition-all"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={handleResetView}
          title="Reset World View"
          aria-label="Reset World View"
          className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#161a20]/90 backdrop-blur-md border border-white/20 text-white flex items-center justify-center shadow-lg hover:bg-stone-700 active:scale-95 transition-all"
        >
          <Maximize2 className="w-3 h-3" />
        </button>
      </div>

      {/* Selection Mode Overlay Prompt Banner */}
      {selectionMode && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-20 bg-amber-400 text-black px-3.5 py-1 rounded-full shadow-2xl font-semibold text-xs tracking-wide flex items-center gap-1.5 animate-bounce">
          <Crosshair className="w-3.5 h-3.5" />
          <span>Click anywhere to run real-time NASA AI risk analysis</span>
        </div>
      )}
    </div>
  );
};
