import React, { useState } from 'react';
import { 
  DisasterZoneDetail 
} from '../data/disasterData';
import { 
  calculateDisasterSeverity 
} from '../utils/disasterCalculations';
import { 
  ShieldAlert, 
  Search, 
  Filter, 
  Users, 
  Layers, 
  Satellite, 
  Compass, 
  ArrowUpRight, 
  Flame, 
  Droplets, 
  Zap, 
  Wind, 
  Sun,
  Eye,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardSectionProps {
  zones: DisasterZoneDetail[];
  onSelectZone: (zone: DisasterZoneDetail) => void;
  activeZoneId: string;
}

export const DashboardSection: React.FC<DashboardSectionProps> = ({
  zones,
  onSelectZone,
  activeZoneId
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [severityFilter, setSeverityFilter] = useState<'all' | 'critical' | 'monitored'>('all');

  const filteredZones = zones.filter(zone => {
    const matchesType = filterType === 'all' || zone.hazardType === filterType;
    const matchesSeverity = severityFilter === 'all' 
      ? true 
      : severityFilter === 'critical' ? zone.status === 'Critical Alert' : zone.status !== 'Critical Alert';
    const matchesSearch = zone.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          zone.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          zone.location.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesType && matchesSeverity && matchesSearch;
  });

  const getHazardIcon = (type: string) => {
    switch (type) {
      case 'flood': return <Droplets className="w-4 h-4 text-cyan-500" />;
      case 'wildfire': return <Flame className="w-4 h-4 text-orange-500" />;
      case 'earthquake': return <Zap className="w-4 h-4 text-rose-500" />;
      case 'cyclone': return <Wind className="w-4 h-4 text-purple-500" />;
      case 'drought': return <Sun className="w-4 h-4 text-amber-500" />;
      default: return <ShieldAlert className="w-4 h-4 text-stone-500" />;
    }
  };

  // Step-down animation container variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: 'easeOut' as const }
    }
  };

  return (
    <section id="dashboard-section" className="relative w-full max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
      
      {/* Background card with rounded styling matching reference */}
      <motion.div 
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.15 }}
        variants={containerVariants}
        className="rounded-[36px] bg-[#f2ebe2] border border-white/60 p-6 sm:p-10 shadow-xl"
      >
        {/* Step 1: Section Header */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-[#dfd4c7]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-tech font-bold">
                REAL-TIME TELEMETRY FEED
              </span>
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl font-light text-[#1c1b18] tracking-tight">
              Disaster Risk Operations Dashboard
            </h2>
            <p className="text-stone-600 text-sm mt-2 max-w-xl">
              Cross-referencing orbital synthetic aperture radar, infrared fire lines, and hydrological runoff across active emergency zones.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/80 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/80 text-xs font-tech text-stone-700 shadow-2xs">
              <span className="text-emerald-600 font-bold">● LIVE DOWNLINK</span> | ORBITAL PASS: 14:32 UTC
            </div>
          </div>
        </motion.div>

        {/* Step 2: Controls & Filters Bar */}
        <motion.div variants={itemVariants} className="pt-6 pb-6 flex flex-wrap items-center justify-between gap-4">
          {/* Hazard type pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
            {[
              { id: 'all', label: 'All Hazards' },
              { id: 'flood', label: 'Floods' },
              { id: 'wildfire', label: 'Wildfires' },
              { id: 'earthquake', label: 'Seismic' },
              { id: 'cyclone', label: 'Cyclones' },
              { id: 'drought', label: 'Drought' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilterType(tab.id)}
                className={`px-4 py-2 rounded-full text-xs font-medium tracking-wide transition-all whitespace-nowrap ${
                  filterType === tab.id
                    ? 'bg-[#1c1b18] text-white shadow-xs'
                    : 'bg-white/60 hover:bg-white text-stone-700 border border-white/60'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search and Severity Filter */}
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-64">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
              <input
                type="text"
                placeholder="Filter by country, region..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white/80 border border-white/80 rounded-full text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
              />
            </div>

            <select
              value={severityFilter}
              onChange={e => setSeverityFilter(e.target.value as any)}
              className="px-3 py-2 bg-white/80 border border-white/80 rounded-full text-xs text-stone-700 focus:outline-none focus:ring-2 focus:ring-amber-500/40"
            >
              <option value="all">All Tiers</option>
              <option value="critical">Critical Only</option>
              <option value="monitored">Monitored Only</option>
            </select>
          </div>
        </motion.div>

        {/* Step 3: Zone Cards Grid (Cascading reveal) */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-2">
          {filteredZones.map((zone) => {
            const isSelected = zone.id === activeZoneId;
            return (
              <div
                key={zone.id}
                onClick={() => {
                  onSelectZone(zone);
                  // Scroll smoothly back to hero map
                  document.getElementById('hero-section')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`group bg-white/95 rounded-[28px] overflow-hidden p-4 border transition-all duration-300 shadow-md hover:shadow-xl cursor-pointer flex flex-col justify-between ${
                  isSelected 
                    ? 'border-[#1c1b18] ring-2 ring-[#1c1b18]/20 bg-[#faf6f1]' 
                    : 'border-white/80 hover:border-stone-300'
                }`}
              >
                <div>
                  {/* Card Thumbnail */}
                  <div className="relative h-44 rounded-[20px] overflow-hidden mb-3.5">
                    <img
                      src={zone.imageUrl}
                      alt={zone.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30" />
                    
                    {/* Top status chips */}
                    <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                      <span className="bg-black/75 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider font-tech flex items-center gap-1">
                        {getHazardIcon(zone.hazardType)}
                        {zone.hazardType}
                      </span>
                    </div>

                    <div className="absolute top-2.5 right-2.5">
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase font-tech shadow-md ${
                        zone.status === 'Critical Alert'
                          ? 'bg-rose-500 text-white'
                          : 'bg-amber-400 text-black'
                      }`}>
                        {zone.status}
                      </span>
                    </div>

                    {/* Bottom coords & satellite */}
                    <div className="absolute bottom-2.5 left-2.5 right-2.5 flex items-center justify-between text-white text-[10px] font-tech">
                      <span>{zone.location}</span>
                      <span className="text-stone-300">{zone.country}</span>
                    </div>
                  </div>

                  {/* Title & Summary */}
                  <h3 className="font-bold text-base text-[#1c1b18] group-hover:text-amber-800 transition-colors">
                    {zone.name}
                  </h3>
                  <p className="text-stone-600 text-xs mt-1 leading-snug line-clamp-2">
                    {zone.summary}
                  </p>

                  {/* Metrics Bar */}
                  <div className="grid grid-cols-3 gap-2 py-3 my-2 border-y border-stone-100 text-center">
                    <div>
                      <div className="text-[10px] text-stone-400 font-tech">POPULATION</div>
                      <div className="text-xs font-bold text-stone-800 font-tech">
                        {(zone.populationAtRisk / 1000).toFixed(0)}k at risk
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 font-tech">AREA</div>
                      <div className="text-xs font-bold text-stone-800 font-tech">
                        {zone.areaKm2} km²
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] text-stone-400 font-tech">INTENSITY</div>
                      <div className="text-xs font-bold text-rose-600 font-tech">
                        {zone.hazardIntensity}/5.0
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Action Link */}
                <div className="pt-2 flex items-center justify-between text-xs font-medium">
                  <span className="text-stone-500 text-[11px] font-tech flex items-center gap-1">
                    <Satellite className="w-3 h-3 text-cyan-600" />
                    {zone.satelliteMission.split('+')[0]}
                  </span>
                  <div className="flex items-center gap-1 text-[#1c1b18] group-hover:text-amber-700 font-semibold text-xs">
                    <span>Inspect on Map</span>
                    <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </motion.div>
      </motion.div>
    </section>
  );
};
