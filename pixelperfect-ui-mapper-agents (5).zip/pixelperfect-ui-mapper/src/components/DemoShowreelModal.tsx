import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, Satellite, ShieldAlert, Cpu, Route, CheckCircle2 } from 'lucide-react';

interface DemoShowreelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DemoShowreelModal: React.FC<DemoShowreelModalProps> = ({ isOpen, onClose }) => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  const steps = [
    {
      title: 'Phase 1: Constellation Ingestion & SAR Radar Beam',
      desc: 'Sentinel-1 C-band Synthetic Aperture Radar pierces dense cloud covers and precipitation, emitting radar pulses to map surface elevation variations at 10-meter spatial resolution.',
      sensor: 'Sentinel-1A SAR • Dual Polarisation (VV+VH)',
      telemetry: 'ALTITUDE: 693 KM • INCLINATION: 98.18° • REVISIT: 6 DAYS',
      img: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1200&q=80',
      badge: 'ORBITAL RADAR'
    },
    {
      title: 'Phase 2: Neural Water & Flood Mask Segmentation',
      desc: 'Convolutional neural networks compute backscatter intensity drops over water surfaces, generating pixel-level flood inundation polygons within 90 seconds of telemetry downlink.',
      sensor: 'SWOT Radar Interferometer + Landsat-9 TIRS',
      telemetry: 'ACCURACY: 94.6% • INUNDATED AREA: 14,200 HA • PEAK DEPTH: 1.8M',
      img: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&w=1200&q=80',
      badge: 'AI SEGMENTATION'
    },
    {
      title: 'Phase 3: Structural Vulnerability & Population Density',
      desc: 'High-resolution optical layers cross-reference building footprints and OpenStreetMap transport networks, flagging impassable bridges, severed highways, and isolated residential sectors.',
      sensor: 'PlanetScope + Sentinel-2 MSI Optical',
      telemetry: 'BRIDGES CRITICAL: 4 • ROADS SEVERED: 38 KM • CIVILIANS ISOLATED: 4,800',
      img: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?auto=format&fit=crop&w=1200&q=80',
      badge: 'DAMAGE MATRIX'
    },
    {
      title: 'Phase 4: Tactical Ground Rescue & Air Corridors',
      desc: 'Sphere-compliant humanitarian routing automatically pushes safe ingress corridors and helicopter landing zones directly to emergency dispatchers and civil protection units.',
      sensor: 'GPS Ground Terminals + NASA GIBS Vector Engine',
      telemetry: 'DISPATCH STATUS: ACTIVE • CORRIDORS OPEN: 3 • HELIPADS VALIDATED: 6',
      img: 'https://images.unsplash.com/photo-1527482797697-8795b05a13fe?auto=format&fit=crop&w=1200&q=80',
      badge: 'MISSION DISPATCH'
    }
  ];

  useEffect(() => {
    if (!isOpen || !isPlaying) return;
    const timer = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % steps.length);
    }, 4500);
    return () => clearInterval(timer);
  }, [isOpen, isPlaying, steps.length]);

  if (!isOpen) return null;

  const current = steps[currentStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-3xl bg-[#14161a] border border-white/15 rounded-[32px] shadow-2xl overflow-hidden flex flex-col text-white"
        role="dialog"
        aria-modal="true"
        aria-labelledby="showreel-heading"
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-[#191c22]">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></span>
            <h3 id="showreel-heading" className="text-sm font-bold tracking-wider font-tech uppercase text-white">
              NASA SPACE APPS • AI DISASTER ANALYSIS SHOWREEL
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Showreel"
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-stone-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video / Visual Simulation Canvas */}
        <div className="relative aspect-video w-full bg-black overflow-hidden group">
          <img
            src={current.img}
            alt={current.title}
            className="w-full h-full object-cover transition-opacity duration-700 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/40" />

          {/* Telemetry overlay grid */}
          <div className="absolute top-4 left-4 flex flex-col gap-1.5">
            <span className="bg-amber-400 text-black text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider font-tech">
              {current.badge}
            </span>
            <div className="bg-black/70 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-lg text-[11px] font-tech text-cyan-300">
              {current.sensor}
            </div>
          </div>

          <div className="absolute top-4 right-4 bg-black/70 backdrop-blur-md border border-white/15 px-3 py-1.5 rounded-lg text-[10px] font-tech text-emerald-400">
            {current.telemetry}
          </div>

          {/* Bottom text overlay on video */}
          <div className="absolute bottom-4 left-6 right-6">
            <h4 className="text-lg md:text-xl font-bold text-white mb-1.5">
              {current.title}
            </h4>
            <p className="text-xs md:text-sm text-stone-300 leading-relaxed max-w-2xl line-clamp-2 md:line-clamp-none">
              {current.desc}
            </p>
          </div>
        </div>

        {/* Playback Controls & Step Scrubbers */}
        <div className="p-6 bg-[#16181e] flex flex-col gap-4 border-t border-white/10">
          <div className="grid grid-cols-4 gap-2">
            {steps.map((s, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setCurrentStep(idx);
                  setIsPlaying(false);
                }}
                className={`text-left p-2.5 rounded-xl border text-xs transition-all ${
                  idx === currentStep
                    ? 'bg-white/15 border-amber-400/80 text-white'
                    : 'bg-white/5 border-white/10 text-stone-400 hover:text-stone-200'
                }`}
              >
                <div className="text-[10px] font-tech font-bold uppercase text-amber-400 mb-0.5">
                  0{idx + 1}
                </div>
                <div className="font-medium truncate">{s.title.split(':')[1] || s.title}</div>
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="px-4 py-2 rounded-full bg-white text-black font-semibold text-xs flex items-center gap-2 hover:bg-stone-200 transition-colors"
              >
                {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-black" />}
                <span>{isPlaying ? 'Pause Demo' : 'Play Demo'}</span>
              </button>
              <button
                onClick={() => {
                  setCurrentStep(0);
                  setIsPlaying(true);
                }}
                className="p-2 rounded-full bg-white/5 hover:bg-white/15 text-stone-300 hover:text-white transition-colors"
                title="Restart"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
            <div className="text-xs text-stone-400 font-tech">
              STEP {currentStep + 1} OF {steps.length} • AUTOMATED TELEMETRY PASS
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
