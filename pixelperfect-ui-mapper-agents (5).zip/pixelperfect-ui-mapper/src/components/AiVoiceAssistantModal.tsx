import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  Sparkles, 
  X, 
  Radio, 
  Satellite, 
  ShieldAlert, 
  Activity, 
  Send, 
  Compass,
  CheckCircle2,
  Zap
} from 'lucide-react';
import { DisasterZoneDetail } from '../data/disasterData';
import { askAssistant, splitForSpeech, synthesizeSpeech, transcribeAudio } from '../services/api';
import { UiAction } from '../ai/uiActions';

interface AiVoiceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeZone: DisasterZoneDetail;
  onUiActions: (actions: UiAction[]) => void;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  telemetry?: {
    satellite: string;
    actionTaken?: string;
    riskScore?: number;
  };
  suggestions?: string[];
  agents?: string[];
}

export const AiVoiceAssistantModal: React.FC<AiVoiceAssistantModalProps> = ({
  isOpen,
  onClose,
  activeZone,
  onUiActions
}) => {
  const [isListening, setIsListening] = useState<boolean>(false); // true while the mic is recording
  const [isTranscribing, setIsTranscribing] = useState<boolean>(false);
  const [speakReplies, setSpeakReplies] = useState<boolean>(true);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const speechRunRef = useRef(0);
  const [voiceVolume, setVoiceVolume] = useState<number[]>([15, 45, 80, 60, 30, 75, 95, 40, 20]);
  const [userInput, setUserInput] = useState<string>('');
  const [isThinking, setIsThinking] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'ai',
      text: `Systems live. I am your NASA Earth Observation AI Copilot. Currently synced to Sentinel-1 SAR and monitoring ${activeZone.name}. Speak or ask a question below.`,
      timestamp: 'Just now',
      telemetry: {
        satellite: activeZone.satelliteMission,
        riskScore: Math.round(activeZone.hazardIntensity * 18)
      }
    }
  ]);

  // Voice wave animation loop when listening
  useEffect(() => {
    if (!isOpen || !isListening) return;

    const interval = setInterval(() => {
      setVoiceVolume([
        Math.floor(20 + Math.random() * 60),
        Math.floor(30 + Math.random() * 70),
        Math.floor(40 + Math.random() * 60),
        Math.floor(15 + Math.random() * 85),
        Math.floor(35 + Math.random() * 65),
        Math.floor(25 + Math.random() * 75),
        Math.floor(50 + Math.random() * 50),
        Math.floor(20 + Math.random() * 60),
        Math.floor(10 + Math.random() * 40),
      ]);
    }, 150);

    return () => clearInterval(interval);
  }, [isOpen, isListening]);

  // Stop mic and speech when the window closes
  useEffect(() => {
    if (isOpen) return;
    recorderRef.current?.state === 'recording' && recorderRef.current.stop();
    stopSpeaking();
  }, [isOpen]);

  if (!isOpen) return null;

  function stopSpeaking() {
    speechRunRef.current++;
    audioRef.current?.pause();
    audioRef.current = null;
    window.speechSynthesis?.cancel();
    setIsSpeaking(false);
  }

  // Agent 5: Groq text to speech, sentence by sentence. Falls back to the browser voice if it fails.
  const speak = async (text: string) => {
    stopSpeaking();
    const run = speechRunRef.current;
    setIsSpeaking(true);
    try {
      const hasDevanagari = /[\u0900-\u097F]/.test(text);
      if (hasDevanagari) throw new Error('Orpheus is English only');
      for (const chunk of splitForSpeech(text)) {
        if (run !== speechRunRef.current) return;
        const url = URL.createObjectURL(await synthesizeSpeech(chunk));
        await new Promise<void>((resolve, reject) => {
          const audio = new Audio(url);
          audioRef.current = audio;
          audio.onended = () => resolve();
          audio.onerror = () => reject(new Error('Audio playback failed'));
          audio.play().catch(reject);
        }).finally(() => URL.revokeObjectURL(url));
      }
    } catch {
      if (run === speechRunRef.current && window.speechSynthesis) {
        const u = new SpeechSynthesisUtterance(text);
        u.lang = /[\u0900-\u097F]/.test(text) ? 'hi-IN' : 'en-IN';
        await new Promise<void>(resolve => {
          u.onend = () => resolve();
          u.onerror = () => resolve();
          window.speechSynthesis.speak(u);
        });
      }
    } finally {
      if (run === speechRunRef.current) setIsSpeaking(false);
    }
  };

  // Agent 4: record from the mic, Groq Whisper turns it into text, then it is sent like a typed message
  const toggleMic = async () => {
    if (isTranscribing || isThinking) return;
    if (recorderRef.current?.state === 'recording') {
      recorderRef.current.stop();
      return;
    }
    stopSpeaking();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      chunksRef.current = [];
      recorder.ondataavailable = e => e.data.size > 0 && chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setIsListening(false);
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size < 1500) return; // nothing was said
        setIsTranscribing(true);
        try {
          const text = await transcribeAudio(blob);
          if (text.trim()) await handleSendQuery(text.trim());
        } catch (err) {
          setMessages(prev => [
            ...prev,
            { id: `err-${Date.now()}`, sender: 'ai', text: err instanceof Error ? err.message : 'Speech to text failed.', timestamp: 'Just now' }
          ]);
        } finally {
          setIsTranscribing(false);
        }
      };
      recorderRef.current = recorder;
      recorder.start();
      setIsListening(true);
    } catch {
      setMessages(prev => [
        ...prev,
        { id: `err-${Date.now()}`, sender: 'ai', text: 'Microphone access was denied or is not available in this browser.', timestamp: 'Just now' }
      ]);
    }
  };

  const quickPrompts = [
    {
      label: 'Scan Valencia SAR flood',
      query: 'Run a high-resolution SAR flood analysis on the Valencia Basin.',
      target: 'Valencia'
    },
    {
      label: 'Calculate relief shelters for Türkiye',
      query: 'Calculate emergency shelters and water logistics for the Hatay fault zone.',
      target: 'Türkiye'
    },
    {
      label: 'Check Maui fire heat anomalies',
      query: 'What do Landsat-9 thermal sensors report on the Lahaina wildfire perimeter?',
      target: 'Maui'
    },
    {
      label: 'Assess Bay of Bengal Cyclone storm surge',
      query: 'Evaluate storm surge polder overtopping in the Sundarbans.',
      target: 'Cyclone'
    }
  ];

  const handleSendQuery = async (textToSend?: string) => {
    const text = textToSend || userInput;
    if (!text.trim() || isThinking) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: text,
      timestamp: 'Just now'
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setUserInput('');
    setIsThinking(true);

    try {
      const history = nextMessages.map(m => ({
        role: m.sender === 'user' ? ('user' as const) : ('assistant' as const),
        content: m.text
      }));
      const result = await askAssistant(history, activeZone.id);

      setMessages(prev => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: result.reply,
          timestamp: 'Just now',
          telemetry: result.telemetry
            ? {
                satellite: result.telemetry.satellite ?? activeZone.satelliteMission,
                riskScore: result.telemetry.riskScore,
                actionTaken: result.actions.length > 0 ? 'Website updated' : undefined
              }
            : undefined,
          suggestions: result.suggestions?.length ? result.suggestions : undefined,
          agents: result.agentTrace?.length ? [...new Set(result.agentTrace.map(t => t.to))] : undefined
        }
      ]);
      onUiActions(result.actions);
      if (speakReplies) void speak(result.reply);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'ai',
          text: err instanceof Error ? err.message : 'The AI service is unreachable right now.',
          timestamp: 'Just now'
        }
      ]);
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="w-full max-w-xl bg-[#17181c] border border-amber-500/30 rounded-[32px] shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-stone-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="ai-assistant-heading"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-[#1c1d22] to-[#17181c]">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-[#17181c] rounded-full animate-pulse"></span>
            </div>
            <div>
              <h3 id="ai-assistant-heading" className="text-sm font-bold tracking-wide text-white flex items-center gap-2">
                NASA AI DISASTER VOICE ASSISTANT
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-tech font-semibold">LIVE</span>
              </h3>
              <p className="text-[11px] text-stone-400">Natural Language Earth Observation & Rescue Query Engine</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close Voice Assistant"
            className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-stone-300 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Voice Visualizer Bar */}
        <div className="px-6 py-4 bg-[#121316] border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleMic}
              disabled={isTranscribing || isThinking}
              className={`w-11 h-11 rounded-full flex items-center justify-center shadow-lg transition-all ${
                isListening 
                  ? 'bg-amber-500 text-black shadow-amber-500/20 ring-4 ring-amber-500/30' 
                  : 'bg-stone-800 text-stone-400 hover:text-white'
              }`}
              title={isListening ? 'Stop and send' : 'Tap to speak'}
            >
              {isListening ? <Mic className="w-5 h-5 animate-pulse" /> : <MicOff className="w-5 h-5" />}
            </button>
            <div>
              <div className="text-xs font-semibold text-white">
                {isListening ? 'Recording... tap to send' : isTranscribing ? 'Converting speech to text...' : isSpeaking ? 'Speaking...' : 'Tap the mic to speak'}
              </div>
              <div className="text-[11px] text-stone-400 font-tech">
                {isListening ? 'Speak your command or query' : 'Hindi, Hinglish or English'}
              </div>
            </div>
          </div>
          <button
            onClick={() => (isSpeaking ? stopSpeaking() : setSpeakReplies(v => !v))}
            aria-label="Toggle spoken replies"
            title={isSpeaking ? 'Stop speaking' : speakReplies ? 'Spoken replies on' : 'Spoken replies off'}
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
              speakReplies || isSpeaking ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-stone-800 text-stone-500'
            }`}
          >
            <Volume2 className={`w-4 h-4 ${isSpeaking ? 'animate-pulse' : ''}`} />
          </button>

          {/* Audio Wave Bars */}
          <div className="flex items-end gap-1 h-8 px-3 py-1 bg-black/40 rounded-xl border border-white/5">
            {voiceVolume.map((vol, i) => (
              <div
                key={i}
                className="w-1.5 rounded-full bg-gradient-to-t from-amber-500 to-emerald-400 transition-all duration-150"
                style={{ height: isListening ? `${Math.max(15, vol)}%` : '15%' }}
              />
            ))}
          </div>
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map(m => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-amber-500 text-black font-medium rounded-tr-xs'
                    : 'bg-[#22242a] text-stone-200 border border-white/10 rounded-tl-xs shadow-md'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-[10px] opacity-75 font-mono">
                  {m.sender === 'user' ? 'YOU (VOICE)' : 'ORBITAL AI ENGINE'}
                </div>
                <div>{m.text}</div>

                {m.agents && (
                  <div className="mt-2 text-[10px] font-tech text-cyan-300">Agents consulted: {m.agents.join(', ')}</div>
                )}
                {m.suggestions && (
                  <ul className="mt-2 pt-2 border-t border-white/10 space-y-1 text-[11px] text-emerald-200 list-disc pl-4">
                    {m.suggestions.map((sg, i) => (
                      <li key={i}>{sg}</li>
                    ))}
                  </ul>
                )}

                {m.telemetry && (
                  <div className="mt-2.5 pt-2 border-t border-white/10 flex flex-wrap items-center gap-2 text-[10px] font-tech text-amber-300">
                    <span className="flex items-center gap-1 bg-black/30 px-2 py-0.5 rounded">
                      <Satellite className="w-3 h-3 text-cyan-400" />
                      {m.telemetry.satellite}
                    </span>
                    {m.telemetry.riskScore && (
                      <span className="bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded border border-rose-500/30">
                        Risk Score: {m.telemetry.riskScore}/100
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          ))}
          {isThinking && (
            <div className="text-[11px] text-stone-400 font-tech animate-pulse">Navigator is working with the map and weather agents...</div>
          )}
        </div>

        {/* Quick Voice Suggestion Chips */}
        <div className="px-6 py-2 bg-[#121316] border-t border-white/5">
          <div className="text-[10px] text-stone-400 uppercase tracking-wider font-semibold mb-1.5 font-tech">
            Suggested Voice Queries:
          </div>
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {quickPrompts.map((p, idx) => (
              <button
                key={idx}
                onClick={() => handleSendQuery(p.query)}
                className="whitespace-nowrap px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/15 border border-white/10 text-[11px] text-stone-300 hover:text-white transition-colors"
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Input Bar */}
        <div className="p-4 bg-[#181a1e] border-t border-white/10 flex items-center gap-2">
          <input
            type="text"
            value={userInput}
            onChange={e => setUserInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSendQuery()}
            placeholder="Type or speak a disaster command..."
            className="flex-1 bg-black/50 border border-white/10 rounded-full px-4 py-2.5 text-xs text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
          />
          <button
            onClick={() => handleSendQuery()}
            className="w-10 h-10 rounded-full bg-amber-500 hover:bg-amber-400 text-black flex items-center justify-center transition-colors shadow-md"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
