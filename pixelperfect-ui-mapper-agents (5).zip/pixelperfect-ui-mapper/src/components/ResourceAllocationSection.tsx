import React, { useState } from 'react';
import { 
  estimateRescueResourceNeeds, 
  calculateDisasterSeverity 
} from '../utils/disasterCalculations';
import { 
  HeartHandshake, 
  Droplet, 
  Home, 
  Stethoscope, 
  Truck, 
  Download, 
  Sliders, 
  AlertCircle, 
  CheckCircle2,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { motion } from 'motion/react';

export const ResourceAllocationSection: React.FC = () => {
  const [population, setPopulation] = useState<number>(85000);
  const [severityScore, setSeverityScore] = useState<number>(75);
  const [areaKm2, setAreaKm2] = useState<number>(350);
  const [copied, setCopied] = useState<boolean>(false);

  const resourceEstimates = estimateRescueResourceNeeds(population, severityScore, areaKm2);

  const handleExport = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.5, ease: 'easeOut' as const }
    }
  };

  return (
    <section id="resources-section" className="relative w-full max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <motion.div
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.15 }}
        variants={containerVariants}
        className="rounded-[36px] bg-[#eee5dc] border border-white/60 p-6 sm:p-10 shadow-xl"
      >
        {/* Step 1: Section Header */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-8 border-b border-[#ded3c6]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] tracking-[0.25em] uppercase text-stone-500 font-tech font-bold">
                SPHERE HUMANITARIAN PROTOCOL
              </span>
              <span className="w-2 h-2 rounded-full bg-cyan-600" />
            </div>
            <h2 className="font-editorial text-4xl sm:text-5xl font-light text-[#1c1b18] tracking-tight">
              AI Emergency Resource Allocation
            </h2>
            <p className="text-stone-600 text-sm mt-2 max-w-xl">
              Real-time logistic calculation translating orbital hazard envelopes into precise humanitarian supply quotas and medical triage dispatch manifests.
            </p>
          </div>

          <button
            onClick={handleExport}
            className="px-5 py-3 rounded-full bg-[#1c1b18] hover:bg-black text-white text-xs font-semibold tracking-wider flex items-center gap-2 shadow-md transition-all self-start md:self-auto active:scale-95"
          >
            {copied ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Download className="w-4 h-4" />}
            <span>{copied ? 'Manifest Copied to Clipboard' : 'Export Dispatch Manifest'}</span>
          </button>
        </motion.div>

        {/* Step 2: Interactive Sliders & Live Results Grid */}
        <motion.div variants={itemVariants} className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-8">
          
          {/* Left Column: Interactive Simulation Sliders */}
          <div className="lg:col-span-5 bg-white/90 backdrop-blur-md rounded-[28px] p-6 border border-white/80 shadow-md space-y-6">
            <div className="flex items-center gap-2 pb-2 border-b border-stone-100">
              <Sliders className="w-4 h-4 text-stone-600" />
              <h3 className="font-bold text-sm text-stone-900">Incident Parameter Controls</h3>
            </div>

            {/* Slider 1: Affected Population */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="font-semibold text-stone-700">Estimated Population at Risk</span>
                <span className="font-tech font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
                  {population.toLocaleString()} civilians
                </span>
              </div>
              <input
                type="range"
                min="5000"
                max="500000"
                step="5000"
                value={population}
                onChange={e => setPopulation(Number(e.target.value))}
                className="w-full accent-[#1c1b18] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-stone-400 font-tech mt-1">
                <span>5,000 (Local enclave)</span>
                <span>500,000 (Major metro)</span>
              </div>
            </div>

            {/* Slider 2: Severity Score */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="font-semibold text-stone-700">Neural Damage Severity Score</span>
                <span className={`font-tech font-bold px-2 py-0.5 rounded text-xs ${
                  severityScore >= 75 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {severityScore} / 100 ({resourceEstimates.priorityLevel})
                </span>
              </div>
              <input
                type="range"
                min="20"
                max="98"
                step="2"
                value={severityScore}
                onChange={e => setSeverityScore(Number(e.target.value))}
                className="w-full accent-rose-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-stone-400 font-tech mt-1">
                <span>Moderate (20)</span>
                <span>Critical Catastrophic (98)</span>
              </div>
            </div>

            {/* Slider 3: Area km² */}
            <div>
              <div className="flex justify-between items-center text-xs mb-2">
                <span className="font-semibold text-stone-700">Inundated / Severed Land Area</span>
                <span className="font-tech font-bold text-stone-900 bg-stone-100 px-2 py-0.5 rounded">
                  {areaKm2} km²
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="2500"
                step="50"
                value={areaKm2}
                onChange={e => setAreaKm2(Number(e.target.value))}
                className="w-full accent-cyan-600 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-stone-400 font-tech mt-1">
                <span>50 km²</span>
                <span>2,500 km²</span>
              </div>
            </div>

            {/* Sphere Standard Info Note */}
            <div className="bg-[#f8f5f0] p-3.5 rounded-2xl border border-stone-200/80 text-[11px] text-stone-600 leading-relaxed">
              <strong className="text-stone-800">Sphere Standard Calculation:</strong> Allocates 15 liters of potable drinking water per person/day, 1 collective shelter per 150 displaced persons, and 1 dedicated mobile medical triage unit per 1,500 individuals.
            </div>
          </div>

          {/* Right Column: Calculated Resource Quotas */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Card 1: Clean Drinking Water */}
            <div className="bg-white/95 rounded-[26px] p-5 border border-white/80 shadow-md flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-cyan-100 text-cyan-700 flex items-center justify-center">
                  <Droplet className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider font-tech bg-cyan-50 text-cyan-700 px-2.5 py-0.5 rounded-full">
                  DAILY POTABLE WATER
                </span>
              </div>
              <div>
                <div className="font-editorial text-3xl sm:text-4xl font-light text-[#1c1b18]">
                  {(resourceEstimates.waterRationsLitersPerDay / 1000).toFixed(0)}k L
                </div>
                <div className="text-xs text-stone-500 font-tech mt-1">
                  {resourceEstimates.waterRationsLitersPerDay.toLocaleString()} Liters / 24hr cycle
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-stone-100 text-[11px] text-stone-600">
                Corresponds to <strong>{Math.ceil(resourceEstimates.waterRationsLitersPerDay / 10000)} water tankers</strong> or emergency filtration bladders.
              </div>
            </div>

            {/* Card 2: Emergency Shelters */}
            <div className="bg-white/95 rounded-[26px] p-5 border border-white/80 shadow-md flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center">
                  <Home className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider font-tech bg-amber-50 text-amber-700 px-2.5 py-0.5 rounded-full">
                  COMMUNAL SHELTERS
                </span>
              </div>
              <div>
                <div className="font-editorial text-3xl sm:text-4xl font-light text-[#1c1b18]">
                  {resourceEstimates.sheltersNeeded} Hubs
                </div>
                <div className="text-xs text-stone-500 font-tech mt-1">
                  Capacity for ~{(resourceEstimates.sheltersNeeded * 150).toLocaleString()} displaced civilians
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-stone-100 text-[11px] text-stone-600">
                High-elevation stadiums, municipal structures, or weather-proof modular tents.
              </div>
            </div>

            {/* Card 3: Medical Emergency Units */}
            <div className="bg-white/95 rounded-[26px] p-5 border border-white/80 shadow-md flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center">
                  <Stethoscope className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider font-tech bg-rose-50 text-rose-700 px-2.5 py-0.5 rounded-full">
                  MEDICAL FIELD TRIAGE
                </span>
              </div>
              <div>
                <div className="font-editorial text-3xl sm:text-4xl font-light text-[#1c1b18]">
                  {resourceEstimates.medicalEmergencyTeams} Units
                </div>
                <div className="text-xs text-stone-500 font-tech mt-1">
                  Trauma kits, portable oxygen, and emergency surgery containers
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-stone-100 text-[11px] text-stone-600">
                Prioritizes field hospitals outside immediate seismic and flood surge zones.
              </div>
            </div>

            {/* Card 4: Evacuation Corridors */}
            <div className="bg-white/95 rounded-[26px] p-5 border border-white/80 shadow-md flex flex-col justify-between">
              <div className="flex items-center justify-between mb-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Truck className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wider font-tech bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-full">
                  INGRESS / EGRESS ROADS
                </span>
              </div>
              <div>
                <div className="font-editorial text-3xl sm:text-4xl font-light text-[#1c1b18]">
                  {resourceEstimates.evacuationRoutesCount} Corridors
                </div>
                <div className="text-xs text-stone-500 font-tech mt-1">
                  Air & ground clearance verified by SAR radar scans
                </div>
              </div>
              <div className="pt-3 mt-3 border-t border-stone-100 text-[11px] text-stone-600">
                Monitored continuously for bridge scouring and road landslides.
              </div>
            </div>

          </div>

        </motion.div>
      </motion.div>
    </section>
  );
};
