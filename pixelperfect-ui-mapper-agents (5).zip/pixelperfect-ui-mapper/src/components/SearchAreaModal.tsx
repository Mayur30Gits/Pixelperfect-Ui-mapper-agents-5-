import React, { useEffect, useState } from 'react';
import { Search, X, MapPin, AlertCircle, ArrowRight } from 'lucide-react';
import { DisasterZoneDetail } from '../data/disasterData';

interface SearchAreaModalProps {
  isOpen: boolean;
  onClose: () => void;
  zones: DisasterZoneDetail[];
  onSelectZone: (zone: DisasterZoneDetail) => void;
  initialQuery?: string;
}

export const SearchAreaModal: React.FC<SearchAreaModalProps> = ({
  isOpen,
  onClose,
  zones,
  onSelectZone,
  initialQuery = ''
}) => {
  const [query, setQuery] = useState('');

  // Each time the modal opens, start from the query the AI (or nothing) provided
  useEffect(() => {
    if (isOpen) setQuery(initialQuery);
  }, [isOpen, initialQuery]);

  if (!isOpen) return null;

  const results = zones.filter(z => 
    z.name.toLowerCase().includes(query.toLowerCase()) ||
    z.country.toLowerCase().includes(query.toLowerCase()) ||
    z.location.toLowerCase().includes(query.toLowerCase()) ||
    z.hazardType.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24 px-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="w-full max-w-lg bg-[#181a1e] border border-white/15 rounded-3xl shadow-2xl overflow-hidden text-stone-100"
        role="dialog"
        aria-modal="true"
        aria-labelledby="search-modal-heading"
      >
        <div className="p-4 border-b border-white/10 flex items-center gap-3 bg-[#1e2127]">
          <Search className="w-5 h-5 text-stone-400" />
          <input
            type="text"
            autoFocus
            placeholder="Search hazard area, country, satellite mission..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-sm text-white placeholder-stone-500 focus:outline-none"
          />
          <button
            onClick={onClose}
            aria-label="Close Search"
            className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 text-stone-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="max-h-80 overflow-y-auto p-3 space-y-2">
          {results.length === 0 ? (
            <div className="text-center py-8 text-stone-400 text-xs">
              No matching disaster zones found for "{query}".
            </div>
          ) : (
            results.map(zone => (
              <div
                key={zone.id}
                onClick={() => {
                  onSelectZone(zone);
                  onClose();
                }}
                className="p-3 rounded-2xl hover:bg-white/10 cursor-pointer flex items-center justify-between transition-colors border border-transparent hover:border-white/10"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl overflow-hidden shrink-0">
                    <img src={zone.imageUrl} alt={zone.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{zone.name}</h4>
                    <p className="text-[11px] text-stone-400">{zone.location}, {zone.country}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase bg-amber-500/20 text-amber-300 font-tech">
                    {zone.hazardType}
                  </span>
                  <ArrowRight className="w-4 h-4 text-stone-400" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
