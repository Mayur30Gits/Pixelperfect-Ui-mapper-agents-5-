import React from 'react';
import { Satellite, Radio, Heart, ShieldCheck, ArrowUpRight } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full max-w-[1480px] mx-auto px-4 sm:px-6 lg:px-8 pb-12 pt-6">
      <div className="rounded-[32px] bg-[#1a1917] text-white p-8 sm:p-10 border border-white/10 shadow-2xl">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-lg bg-white text-black flex items-center justify-center font-editorial font-bold text-lg italic">
                DR
              </div>
              <span className="font-bold text-sm tracking-[0.2em] uppercase font-sans">
                DISASTER RISK MAPPING
              </span>
            </div>
            <p className="text-xs text-stone-400 max-w-md">
              Developed for the NASA Space Apps Hackathon. Fusing Sentinel-1 SAR, SWOT, and Landsat-9 observations with open geospatial AI models.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-2 rounded-full text-xs font-tech text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>ORBITAL DATA PIPELINE: OPERATIONAL</span>
            </div>
          </div>
        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-400 font-tech">
          <div>
            © 2026 Disaster Risk Mapping Project • NASA Space Apps Hackathon Global Submission
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-white cursor-pointer transition-colors">Data Privacy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Sphere Guidelines</span>
            <span className="hover:text-white cursor-pointer transition-colors">Sentinel Hub API</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
