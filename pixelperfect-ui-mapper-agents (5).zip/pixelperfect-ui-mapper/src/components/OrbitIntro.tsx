import React, { useRef } from 'react';
import { motion, useScroll, useTransform, transform, MotionValue } from 'motion/react';
import { ChevronDown } from 'lucide-react';

// Hosted locally: NASA Blue Marble (three-globe), Sun texture by Solar System Scope (CC BY 4.0)
const EARTH_TEXTURE = '/textures/earth-blue-marble.jpg';
const SUN_TEXTURE = '/textures/sun.jpg';
const STARS_TEXTURE = '/textures/night-sky.png';

// Scroll phases (0..1 across the intro section)
const ORBIT_END = 0.45;    // Earth completes its orbit around the Sun
const APPROACH_END = 0.72; // camera flies toward Earth
const ORBIT_RADIUS = 34;   // vmin
const ORBIT_TILT = 0.32;   // ellipse flattening for a tilted-orbit perspective
const EARTH_BASE_SCALE = 0.2; // Earth is rendered at 70vmin in CSS; 0.2 => 14vmin on screen

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const smooth = (t: number) => t * t * (3 - 2 * t);

function getScene(p: number) {
  const orbitT = clamp01(p / ORBIT_END);
  const approachT = smooth(clamp01((p - ORBIT_END) / (APPROACH_END - ORBIT_END)));
  const diveT = clamp01((p - APPROACH_END) / (1 - APPROACH_END));

  // 1.25 revolutions, ending in front of the Sun
  const angle = orbitT * 2.5 * Math.PI;
  const depth = Math.sin(angle); // > 0 means Earth is in front of the Sun

  const sunX = lerp(0, -95, approachT);
  const orbitX = sunX + Math.cos(angle) * ORBIT_RADIUS;
  const orbitY = Math.sin(angle) * ORBIT_RADIUS * ORBIT_TILT;

  return {
    sunX,
    sunScale: lerp(1, 0.55, approachT),
    orbitOpacity: 1 - approachT,
    earthX: lerp(orbitX, 0, approachT),
    earthY: lerp(orbitY, 0, approachT),
    earthScale: EARTH_BASE_SCALE * lerp(0.85 + depth * 0.15, 1.9, approachT) * (1 + diveT * diveT * 16),
    earthZ: depth > 0 || approachT > 0 ? 3 : 1,
    fadeToPage: clamp01((diveT - 0.55) / 0.45),
  };
}

const useScene = <K extends keyof ReturnType<typeof getScene>>(progress: MotionValue<number>, key: K) =>
  useTransform(progress, p => getScene(p)[key]);

export const OrbitIntro: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start start', 'end end'] });

  const sunX = useTransform(useScene(scrollYProgress, 'sunX'), v => `${v}vmin`);
  const sunScale = useScene(scrollYProgress, 'sunScale');
  const orbitOpacity = useScene(scrollYProgress, 'orbitOpacity');
  const earthX = useTransform(useScene(scrollYProgress, 'earthX'), v => `${v}vmin`);
  const earthY = useTransform(useScene(scrollYProgress, 'earthY'), v => `${v}vmin`);
  const earthScale = useScene(scrollYProgress, 'earthScale');
  const earthZ = useScene(scrollYProgress, 'earthZ');
  const fadeToPage = useScene(scrollYProgress, 'fadeToPage');

  // Function form avoids Motion's native ScrollTimeline acceleration, which tracks the whole page instead of this section
  const titleOpacity = useTransform(scrollYProgress, p => transform(p, [0, 0.18, 0.28], [1, 1, 0]));
  const titleY = useTransform(scrollYProgress, p => `${transform(p, [0, 0.28], [0, -6])}vh`);
  const caption2Opacity = useTransform(scrollYProgress, p => transform(p, [0.36, 0.44, 0.58, 0.66], [0, 1, 1, 0]));
  const caption3Opacity = useTransform(scrollYProgress, p => transform(p, [0.7, 0.76, 0.86, 0.92], [0, 1, 1, 0]));

  const skipIntro = () => {
    document.getElementById('hero-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section ref={sectionRef} id="orbit-intro" className="relative h-[320vh]" aria-label="Orbit intro">
      <div className="sticky top-0 h-screen w-full overflow-hidden bg-[#03050a]">
        {/* Starfield */}
        <div
          className="absolute inset-0 opacity-70 bg-cover bg-center"
          style={{ backgroundImage: `url(${STARS_TEXTURE})` }}
        />

        {/* Orbit path (centered on the Sun) */}
        <motion.div
          aria-hidden="true"
          className="orbit-path"
          style={{
            x: sunX,
            opacity: orbitOpacity,
            width: `${ORBIT_RADIUS * 2}vmin`,
            height: `${ORBIT_RADIUS * 2 * ORBIT_TILT}vmin`,
          }}
        />

        {/* Sun */}
        <motion.div aria-hidden="true" className="orbit-body orbit-sun-wrap" style={{ x: sunX, scale: sunScale, zIndex: 2 }}>
          <div className="orbit-sun-corona" />
          <div className="orbit-sun" style={{ backgroundImage: `url(${SUN_TEXTURE})` }} />
        </motion.div>

        {/* Earth */}
        <motion.div
          aria-hidden="true"
          className="orbit-body orbit-earth-wrap"
          style={{ x: earthX, y: earthY, scale: earthScale, zIndex: earthZ }}
        >
          <div className="orbit-earth" style={{ backgroundImage: `url(${EARTH_TEXTURE})` }} />
        </motion.div>

        {/* Captions */}
        <motion.div
          className="absolute inset-x-0 top-[12vh] z-10 flex flex-col items-center text-center px-6 pointer-events-none"
          style={{ opacity: titleOpacity, y: titleY }}
        >
          <span className="text-[10px] sm:text-xs tracking-[0.4em] uppercase text-amber-300/90 font-semibold mb-4">
            NASA Space Apps · Disaster Risk Mapping
          </span>
          <h1 className="font-editorial text-white text-5xl sm:text-7xl font-light tracking-tight leading-[1.05]">
            Seeing Earth <span className="italic">from orbit</span>
          </h1>
        </motion.div>

        <motion.p
          className="absolute inset-x-0 top-[14vh] z-10 text-center px-6 font-editorial text-white text-3xl sm:text-5xl font-light pointer-events-none"
          style={{ opacity: caption2Opacity }}
        >
          Every hazard, watched from space
        </motion.p>

        <motion.p
          className="absolute inset-x-0 bottom-[16vh] z-10 text-center px-6 font-editorial text-white text-3xl sm:text-5xl font-light italic pointer-events-none drop-shadow-lg"
          style={{ opacity: caption3Opacity }}
        >
          …down to the ground where it matters
        </motion.p>

        {/* Scroll hint + skip */}
        <motion.div
          className="absolute bottom-8 inset-x-0 z-10 flex flex-col items-center gap-3"
          style={{ opacity: titleOpacity }}
        >
          <span className="text-[11px] tracking-[0.3em] uppercase text-stone-300">Scroll to descend</span>
          <ChevronDown className="w-5 h-5 text-stone-300 animate-bounce" />
        </motion.div>
        <button
          onClick={skipIntro}
          className="absolute top-5 right-5 z-20 px-4 py-2 rounded-full border border-white/25 bg-white/10 backdrop-blur-md text-white text-xs tracking-wider hover:bg-white/20 transition-colors"
        >
          Skip intro
        </button>

        {/* Blend into the page background at the end of the dive */}
        <motion.div className="absolute inset-0 z-30 bg-[#d8cec4] pointer-events-none" style={{ opacity: fadeToPage }} />
      </div>
    </section>
  );
};
