export const NASA_API_KEY = import.meta.env.VITE_NASA_API_KEY || 'OvwvQmq92yY6pNBh0Idv8vtE84vkQgBO42pGRQSe';

export interface NasaLiveEvent {
  id: string;
  title: string;
  category: string;
  coordinates: [number, number]; // [lat, lng]
  date: string;
  link?: string;
  source: string;
}

export interface NasaEpicImage {
  identifier: string;
  caption: string;
  image: string;
  date: string;
  centroidCoordinates: {
    lat: number;
    lon: number;
  };
}

/**
 * NASA GIBS (Global Imagery Browse Services) Tile Layer Endpoints
 */
export const NASA_GIBS_TILE_URLS = {
  // High-Resolution Satellite Imagery
  highRes: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  
  // NASA VIIRS SNPP Corrected Reflectance (True Color)
  nasaViirsTrueColor: 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_SNPP_CorrectedReflectance_TrueColor/default/default/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg',
  
  // NASA Black Marble Nighttime Lights (Infrastructure & Blackout monitoring) — native max zoom 8
  nasaNightLights: 'https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_Black_Marble/default/default/GoogleMapsCompatible_Level8/{z}/{y}/{x}.png',
  
  // Synthetic Aperture Radar Dark Basemap
  sarRadar: 'https://{s}.basemaps.cartocdn.com/rastertiles/dark_all/{z}/{x}/{y}{r}.png'
};

/**
 * Fetches live real-time natural disaster events from NASA EONET
 */
export async function fetchNasaLiveEvents(limit: number = 8, category?: string): Promise<NasaLiveEvent[]> {
  try {
    const categoryParam = category ? `&category=${encodeURIComponent(category)}` : '';
    const res = await fetch(`https://eonet.gsfc.nasa.gov/api/v3/events?limit=${limit}&status=open${categoryParam}`);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    
    if (!data.events || !Array.isArray(data.events)) {
      return [];
    }

    const events: NasaLiveEvent[] = [];
    for (const ev of data.events) {
      if (ev.geometry && ev.geometry.length > 0) {
        // EONET stores geometry as [lng, lat]
        const latestGeom = ev.geometry[ev.geometry.length - 1];
        if (Array.isArray(latestGeom.coordinates) && latestGeom.coordinates.length >= 2) {
          const lng = latestGeom.coordinates[0];
          const lat = latestGeom.coordinates[1];
          if (typeof lat === 'number' && typeof lng === 'number' && !isNaN(lat) && !isNaN(lng)) {
            events.push({
              id: ev.id,
              title: ev.title,
              category: ev.categories?.[0]?.title || 'Natural Hazard',
              coordinates: [lat, lng],
              date: latestGeom.date ? new Date(latestGeom.date).toLocaleDateString() : 'Active',
              link: ev.link,
              source: ev.sources?.[0]?.id || 'NASA Earth Science'
            });
          }
        }
      }
    }
    return events;
  } catch (err) {
    console.warn('NASA EONET fetch fallback:', err);
    return [];
  }
}

/**
 * Fetches latest NASA EPIC (Earth Polychromatic Imaging Camera) deep-space observation telemetry
 */
export async function fetchNasaEpicTelemetry(): Promise<NasaEpicImage | null> {
  try {
    const res = await fetch(`https://api.nasa.gov/EPIC/api/natural?api_key=${NASA_API_KEY}`);
    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    if (Array.isArray(data) && data.length > 0) {
      const item = data[0];
      return {
        identifier: item.identifier,
        caption: item.caption,
        image: item.image,
        date: item.date,
        centroidCoordinates: {
          lat: item.centroid_coordinates?.lat || 0,
          lon: item.centroid_coordinates?.lon || 0
        }
      };
    }
    return null;
  } catch (err) {
    console.warn('NASA EPIC fetch fallback:', err);
    return null;
  }
}
