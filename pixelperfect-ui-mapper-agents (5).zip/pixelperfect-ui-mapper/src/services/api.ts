import type { UiAction } from '../ai/uiActions';
import type { CommunityReport } from '../data/disasterData';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`/api${path}`, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data as T;
}

export interface AgentTraceEntry {
  from: string;
  to: string;
  task: string;
  ok: boolean;
  ms: number;
}

export interface AssistantReply {
  reply: string;
  actions: UiAction[];
  telemetry?: { satellite?: string; riskScore?: number };
  suggestions?: string[];
  agentTrace?: AgentTraceEntry[];
}

export const askAssistant = (messages: { role: 'user' | 'assistant'; content: string }[], activeZoneId: string) =>
  request<AssistantReply>('/assistant/chat', {
    method: 'POST',
    body: JSON.stringify({ messages, activeZoneId })
  });

export interface LocationAnalysis {
  nearestZone: { name: string; distanceKm: number };
  withinTrackedZone: boolean;
  risk: { score: number; tier: string } | null;
  nearbyLiveEvents: { title: string; distanceKm: number }[];
}

export const analyzeLocationApi = (lat: number, lng: number) =>
  request<LocationAnalysis>('/analysis/location', { method: 'POST', body: JSON.stringify({ lat, lng }) });

// Best effort: the community feed keeps working from localStorage if the server is unreachable
export const postCommunityReport = (report: CommunityReport) =>
  request('/community/reports', { method: 'POST', body: JSON.stringify(report) }).catch(() => undefined);

// ---- Speech: agent 4 (speech to text) and agent 5 (text to speech) ----
export async function transcribeAudio(blob: Blob): Promise<string> {
  const res = await fetch('/api/voice/stt', {
    method: 'POST',
    headers: { 'Content-Type': blob.type || 'audio/webm' },
    body: blob
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Speech to text failed (${res.status})`);
  return String(data.text ?? '');
}

export async function synthesizeSpeech(text: string): Promise<Blob> {
  const res = await fetch('/api/voice/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text })
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.error || `Text to speech failed (${res.status})`);
  }
  return res.blob();
}

/** Orpheus accepts at most 200 characters per request, so replies are spoken sentence by sentence. */
export function splitForSpeech(text: string, max = 190): string[] {
  const sentences = text.replace(/\s+/g, ' ').trim().match(/[^.!?।]+[.!?।]*/g) ?? [];
  const chunks: string[] = [];
  let cur = '';
  for (const raw of sentences) {
    const s = raw.trim();
    if (!s) continue;
    if ((cur + ' ' + s).trim().length <= max) {
      cur = (cur + ' ' + s).trim();
      continue;
    }
    if (cur) chunks.push(cur);
    cur = s;
    while (cur.length > max) {
      const cut = cur.lastIndexOf(' ', max);
      chunks.push(cur.slice(0, cut > 0 ? cut : max));
      cur = cur.slice(cut > 0 ? cut + 1 : max);
    }
  }
  if (cur) chunks.push(cur);
  return chunks;
}
