// Website actions the AI assistant is allowed to trigger (the backend returns them, App.tsx runs them)
export interface UiAction {
  name: string;
  args: Record<string, any>;
}

// Section names the AI uses -> element ids already on the page
export const SECTION_IDS: Record<string, string> = {
  hero: 'hero-section',
  dashboard: 'dashboard-section',
  community: 'community-section',
  resources: 'resources-section',
  about: 'about-section'
};

export type MapLayerKey = 'satellite' | 'nasaViirs' | 'nasaFires' | 'nasaNight' | 'sar';

export type MapCommand =
  | { type: 'flyTo'; lat: number; lng: number; zoom?: number }
  | { type: 'setLayer'; layer: MapLayerKey }
  | { type: 'analyze'; lat: number; lng: number };

export const MAP_COMMAND_EVENT = 'drm:map-command';

// The map lives deep inside HeroSection, so commands reach it through a window event
export const sendMapCommand = (cmd: MapCommand) =>
  window.dispatchEvent(new CustomEvent<MapCommand>(MAP_COMMAND_EVENT, { detail: cmd }));
