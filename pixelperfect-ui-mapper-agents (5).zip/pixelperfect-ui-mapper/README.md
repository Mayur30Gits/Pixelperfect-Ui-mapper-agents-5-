<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/951af458-e017-4cf3-aed5-78525b8060fb

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## Multi-agent AI (Groq)

Five agents, each with its own key in `.env.local` (see `.env.example`). They talk through `server/agents/bus.ts`.

| # | Agent | Key | Job |
|---|-------|-----|-----|
| 1 | Navigator (`server/ai.ts`) | `GROQ_KEY_NAVIGATOR` | Controls the website with function calling, delegates to agents 2 and 3 |
| 2 | Map analyst (`server/agents/mapAnalyst.ts`) | `GROQ_KEY_MAP` | Map/zone analysis, risk, suggested actions; can ask the weather agent |
| 3 | Weather (`server/agents/weatherAgent.ts`) | `GROQ_KEY_WEATHER` | 7-day forecast (Open-Meteo) + hazard prediction; can ask the map analyst |
| 4 | Speech to text (`server/agents/speech.ts`) | `GROQ_KEY_STT` | Whisper `whisper-large-v3-turbo` |
| 5 | Text to speech (`server/agents/speech.ts`) | `GROQ_KEY_TTS` | Orpheus `canopylabs/orpheus-v1-english` |

Endpoints: `POST /api/assistant/chat`, `POST /api/voice/stt`, `POST /api/voice/tts`, `POST /api/agents/map`, `POST /api/agents/weather`, `GET /api/weather/forecast`, `GET /api/agents/status`.
