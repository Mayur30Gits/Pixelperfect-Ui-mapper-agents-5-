import express, { NextFunction, Request, Response, Router } from 'express';
import { CommunityReport, DISASTER_ZONES } from '../src/data/disasterData';
import { analyzeLocation, analyzeZone, findZone } from './analysis';
import { runAssistant, ChatMessage } from './ai';
import { authOptional, authRequired, login, publicUser, register } from './auth';
import { AGENT_KEYS, GROQ_API_KEY, MODELS } from './config';
import { AgentCtx, callAgent, newCtx } from './agents/bus';
import { speechToText, textToSpeech } from './agents/speech';
import { getForecast } from './weather';
import { getEpicLatest, getLiveEvents, getZoneHistory } from './nasa';
import { getDb, saveDb } from './store';
import { HttpError, parseCoords, rateLimit } from './util';

export const api = Router();
api.use(express.json({ limit: '6mb' }));

const wrap = (fn: (req: Request, res: Response, next: NextFunction) => unknown) =>
  (req: Request, res: Response, next: NextFunction) => Promise.resolve(fn(req, res, next)).catch(next);

const zoneOr404 = (id: string) => {
  const zone = findZone(id);
  if (!zone) throw new HttpError(404, 'Unknown zone id.');
  return zone;
};

api.get('/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(AGENT_KEYS.navigator || GROQ_API_KEY) }));

// Which of the 5 agents have a key (never returns the keys themselves)
api.get('/agents/status', (_req, res) => {
  const status = (Object.keys(AGENT_KEYS) as (keyof typeof AGENT_KEYS)[]).map(name => ({
    agent: name,
    configured: Boolean(AGENT_KEYS[name]),
    keyLooksValid: AGENT_KEYS[name].startsWith('gsk_'),
    model: MODELS[name]
  }));
  res.json(status);
});

/* ---------- 1. Data backend (NASA) ---------- */
api.get('/data/zones', (_req, res) => res.json(DISASTER_ZONES));
api.get('/data/events', wrap(async (req, res) => {
  const category = typeof req.query.category === 'string' ? req.query.category : undefined;
  res.json(await getLiveEvents({ limit: Number(req.query.limit) || 20, category }));
}));
api.get('/data/epic', wrap(async (_req, res) => res.json(await getEpicLatest())));

/* ---------- 2. AI analysis backend ---------- */
api.get('/analysis/zone/:id', (req, res) => res.json(analyzeZone(zoneOr404(req.params.id))));
api.post('/analysis/location', wrap(async (req, res) => {
  const [lat, lng] = parseCoords(req.body?.lat, req.body?.lng);
  res.json(await analyzeLocation(lat, lng));
}));

/* ---------- 5. Historical data backend ---------- */
api.get('/history/:zoneId', wrap(async (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 365, 1), 3650);
  res.json(await getZoneHistory(zoneOr404(req.params.zoneId), days));
}));

/* ---------- 4. Community data backend ---------- */
const KINDS = ['Alert', 'Damage', 'Photo'];
const SEVERITIES = ['Critical', 'Severe', 'Moderate', 'Minor'];

api.get('/community/reports', (_req, res) => res.json(getDb().reports));

api.post('/community/reports', authOptional, (req, res) => {
  const b = req.body ?? {};
  const locationName = String(b.locationName ?? '').trim().slice(0, 120);
  const notes = String(b.notes ?? '').trim().slice(0, 1000);
  const kind = KINDS.includes(b.kind) ? b.kind : 'Alert';
  const severity = SEVERITIES.includes(b.severity) ? b.severity : 'Moderate';
  if (!locationName || !notes) throw new HttpError(400, 'locationName and notes are required.');

  let coordinates: [number, number] | undefined;
  if (Array.isArray(b.coordinates)) coordinates = parseCoords(b.coordinates[0], b.coordinates[1]);

  const photoUrl = typeof b.photoUrl === 'string' && b.photoUrl.startsWith('data:image/') ? b.photoUrl : undefined;
  if (photoUrl && photoUrl.length > 2_500_000) throw new HttpError(413, 'Photo is too large.');
  if (kind === 'Photo' && !photoUrl) throw new HttpError(400, 'A photo report needs a photo.');

  const db = getDb();
  const clientId = typeof b.id === 'string' && /^rep-[\w-]{1,40}$/.test(b.id) ? b.id : '';
  const id = clientId && !db.reports.some(r => r.id === clientId) ? clientId : `rep-${Date.now()}`;
  const author = db.users.find(u => u.id === res.locals.userId);

  const report: CommunityReport & { userId?: string } = {
    id,
    kind,
    locationName,
    hazardType: String(b.hazardType ?? 'Unspecified').slice(0, 80),
    severity,
    timestamp: 'Just now',
    createdAt: Date.now(),
    reporter: String(b.reporter ?? '').trim().slice(0, 60) || author?.name || 'Anonymous Volunteer',
    verified: false,
    notes,
    coordinates,
    photoUrl,
    votes: 1,
    userId: author?.id
  };
  db.reports.unshift(report);
  saveDb();
  res.status(201).json(report);
});

api.post('/community/reports/:id/vote', rateLimit(30, 60_000), (req, res) => {
  const report = getDb().reports.find(r => r.id === req.params.id);
  if (!report) throw new HttpError(404, 'Report not found.');
  report.votes += 1;
  report.verified = report.verified || report.votes >= 3;
  saveDb();
  res.json(report);
});

/* ---------- 6. Auth backend (optional login/profile) ---------- */
api.post('/auth/register', rateLimit(10, 60_000), wrap(async (req, res) => {
  res.status(201).json(await register(req.body?.email, req.body?.password, req.body?.name));
}));
api.post('/auth/login', rateLimit(10, 60_000), wrap(async (req, res) => {
  res.json(await login(req.body?.email, req.body?.password));
}));
api.get('/auth/me', authRequired, (_req, res) => {
  const user = getDb().users.find(u => u.id === res.locals.userId);
  res.json(user ? publicUser(user) : null);
});

/* ---------- 3. AI assistant backend (Groq) ---------- */
api.post('/assistant/chat', rateLimit(20, 60_000), wrap(async (req, res) => {
  const raw: unknown[] = Array.isArray(req.body?.messages) ? req.body.messages : [];
  const messages: ChatMessage[] = raw
    .filter((m: any) => (m?.role === 'user' || m?.role === 'assistant') && typeof m.content === 'string' && m.content.trim())
    .map((m: any) => ({ role: m.role, content: m.content.slice(0, 2000) }));
  if (messages.length === 0 || messages[messages.length - 1].role !== 'user') {
    throw new HttpError(400, 'messages must end with a user message.');
  }
  const activeZoneId = typeof req.body?.activeZoneId === 'string' ? req.body.activeZoneId : undefined;
  res.json(await runAssistant(messages, activeZoneId));
}));

/* ---------- 4. Speech to text / 5. Text to speech ---------- */
api.post('/voice/stt', rateLimit(30, 60_000), express.raw({ type: () => true, limit: '10mb' }), wrap(async (req, res) => {
  const audio = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
  res.json(await speechToText(audio, String(req.headers['content-type'] ?? 'audio/webm')));
}));

api.post('/voice/tts', rateLimit(60, 60_000), wrap(async (req, res) => {
  const audio = await textToSpeech(String(req.body?.text ?? ''), typeof req.body?.voice === 'string' ? req.body.voice : undefined);
  res.setHeader('Content-Type', 'audio/wav');
  res.setHeader('Cache-Control', 'no-store');
  res.send(audio);
}));

/* ---------- Weather + direct agent endpoints ---------- */
api.get('/weather/forecast', wrap(async (req, res) => {
  const [lat, lng] = parseCoords(req.query.lat, req.query.lng);
  res.json(await getForecast(lat, lng));
}));

const directAgent = (to: 'map' | 'weather') =>
  wrap(async (req, res) => {
    const b = req.body ?? {};
    const ctx: AgentCtx = newCtx(typeof b.activeZoneId === 'string' ? b.activeZoneId : undefined);
    const args: Record<string, any> = { zone_id: b.zone_id, lat: b.lat, lng: b.lng };
    const task = String(b.task ?? (to === 'map' ? 'Analyse this area and suggest actions' : 'Predict the weather hazards')).slice(0, 500);
    const result = await callAgent('navigator', to, task, args, ctx);
    res.json({ result, agentTrace: ctx.trace });
  });
api.post('/agents/map', rateLimit(20, 60_000), directAgent('map'));
api.post('/agents/weather', rateLimit(20, 60_000), directAgent('weather'));

/* ---------- errors ---------- */
api.use((_req, _res, next) => next(new HttpError(404, 'Not found.')));
api.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err instanceof HttpError ? err.status : typeof err?.status === 'number' && err.status < 500 ? err.status : 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Internal server error.' : err.message });
});
