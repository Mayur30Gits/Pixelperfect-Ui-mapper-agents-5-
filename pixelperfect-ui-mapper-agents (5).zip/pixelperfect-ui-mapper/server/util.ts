import type { NextFunction, Request, Response } from 'express';

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

const cache = new Map<string, { at: number; value: unknown }>();

/** Tiny in-memory TTL cache so NASA endpoints are not hit on every request. */
export async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  const value = await load();
  cache.set(key, { at: Date.now(), value });
  return value;
}

/** Per-IP request limiter (protects the Groq key and auth endpoints). */
export function rateLimit(max: number, windowMs: number) {
  const hits = new Map<string, number[]>();
  return (req: Request, _res: Response, next: NextFunction) => {
    const ip = req.ip || 'unknown';
    const now = Date.now();
    const recent = (hits.get(ip) || []).filter(t => now - t < windowMs);
    if (recent.length >= max) return next(new HttpError(429, 'Too many requests, please slow down.'));
    recent.push(now);
    hits.set(ip, recent);
    next();
  };
}

const toNumber = (v: unknown) =>
  typeof v === 'number' ? v : typeof v === 'string' && v.trim() !== '' ? Number(v) : NaN;

export function parseCoords(lat: unknown, lng: unknown): [number, number] {
  const a = toNumber(lat);
  const b = toNumber(lng);
  if (!Number.isFinite(a) || !Number.isFinite(b) || Math.abs(a) > 90 || Math.abs(b) > 180) {
    throw new HttpError(400, 'lat must be between -90 and 90, lng between -180 and 180.');
  }
  return [a, b];
}
