import { NASA_API_KEY } from './config';
import { cached, HttpError } from './util';
import type { DisasterZoneDetail } from '../src/data/disasterData';
import { calculateDistanceKm } from '../src/utils/disasterCalculations';

export interface LiveEvent {
  id: string;
  title: string;
  category: string;
  coordinates: [number, number]; // [lat, lng]
  date: string;
  link?: string;
  source: string;
}

// Our zone hazard types -> NASA EONET category ids
export const HAZARD_TO_EONET: Record<DisasterZoneDetail['hazardType'], string> = {
  flood: 'floods',
  wildfire: 'wildfires',
  cyclone: 'severeStorms',
  earthquake: 'earthquakes',
  landslide: 'landslides',
  drought: 'drought'
};

const HISTORY_RADIUS_KM = 500;

async function nasaFetch(url: string, label: string) {
  try {
    return await fetch(url, { signal: AbortSignal.timeout(10_000) });
  } catch {
    throw new HttpError(502, `${label} is unreachable right now.`);
  }
}

interface EventQuery {
  limit?: number;
  category?: string;
  status?: 'open' | 'closed';
  days?: number;
}

/** Data backend: live (open) or past (closed) natural events from NASA EONET. */
export function getLiveEvents({ limit = 20, category, status = 'open', days }: EventQuery = {}): Promise<LiveEvent[]> {
  const params = new URLSearchParams({ limit: String(Math.min(Math.max(limit, 1), 500)), status });
  if (category) params.set('category', category);
  if (days) params.set('days', String(days));
  const url = `https://eonet.gsfc.nasa.gov/api/v3/events?${params}`;

  return cached(url, 5 * 60_000, async () => {
    const res = await nasaFetch(url, 'NASA EONET');
    if (!res.ok) throw new HttpError(502, `NASA EONET responded with ${res.status}`);
    const data: any = await res.json();
    const events: LiveEvent[] = [];
    for (const ev of data.events ?? []) {
      const geom = ev.geometry?.at(-1);
      const [lng, lat] = geom?.coordinates ?? []; // EONET stores [lng, lat]
      if (typeof lat === 'number' && typeof lng === 'number') {
        events.push({
          id: ev.id,
          title: ev.title,
          category: ev.categories?.[0]?.title ?? 'Natural Hazard',
          coordinates: [lat, lng],
          date: geom.date ?? '',
          link: ev.link,
          source: ev.sources?.[0]?.id ?? 'NASA EONET'
        });
      }
    }
    return events;
  });
}

/** Data backend: latest NASA EPIC (Earth Polychromatic Imaging Camera) image metadata. */
export function getEpicLatest() {
  const url = `https://api.nasa.gov/EPIC/api/natural?api_key=${NASA_API_KEY}`;
  return cached(url, 30 * 60_000, async () => {
    const res = await nasaFetch(url, 'NASA EPIC');
    if (!res.ok) throw new HttpError(502, `NASA EPIC responded with ${res.status}`);
    const data: any = await res.json();
    const item = Array.isArray(data) ? data[0] : null;
    return item
      ? {
          identifier: item.identifier,
          caption: item.caption,
          image: item.image,
          date: item.date,
          centroidCoordinates: item.centroid_coordinates ?? null
        }
      : null;
  });
}

/** Historical backend: past (closed) vs currently open events of the same hazard near a zone. */
export async function getZoneHistory(zone: DisasterZoneDetail, days = 365) {
  const category = HAZARD_TO_EONET[zone.hazardType];
  const [past, open] = await Promise.all([
    getLiveEvents({ category, status: 'closed', days, limit: 200 }),
    getLiveEvents({ category, status: 'open', limit: 200 })
  ]);
  const [zLat, zLng] = zone.coordinates;
  const nearby = (list: LiveEvent[]) =>
    list
      .map(e => ({ ...e, distanceKm: calculateDistanceKm(zLat, zLng, e.coordinates[0], e.coordinates[1]) }))
      .filter(e => e.distanceKm <= HISTORY_RADIUS_KM)
      .sort((a, b) => a.distanceKm - b.distanceKm);

  const pastNear = nearby(past);
  const openNear = nearby(open);
  return {
    zoneId: zone.id,
    zoneName: zone.name,
    hazardType: zone.hazardType,
    eonetCategory: category,
    windowDays: days,
    radiusKm: HISTORY_RADIUS_KM,
    pastEventsNearby: pastNear.length,
    openEventsNearby: openNear.length,
    recentPastEvents: pastNear.slice(0, 10)
  };
}
