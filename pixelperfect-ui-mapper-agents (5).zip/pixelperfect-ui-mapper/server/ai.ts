// Agent 1: Navigator + function calling (orchestrator). It controls the website and
// delegates to the Map Analysis agent and the Weather agent through the agent bus.
import { DISASTER_ZONES } from '../src/data/disasterData';
import { MODELS } from './config';
import { findZone } from './analysis';
import { AgentCtx, callAgent, newCtx, TraceEntry } from './agents/bus';
import { DATA_TOOLS, runDataTool } from './agents/dataTools';
import { runToolLoop, tool } from './agents/loop';
import './agents/mapAnalyst';
import './agents/weatherAgent';

export interface UiAction {
  name: string;
  args: Record<string, unknown>;
}
export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

const SECTIONS = ['hero', 'dashboard', 'community', 'resources', 'about'];
const LAYERS = ['satellite', 'nasaViirs', 'nasaFires', 'nasaNight', 'sar'];

// Agent-to-agent tools: the navigator hands deep analysis / forecasting to the specialists
const AGENT_TOOLS = [
  tool('ask_map_analyst', 'Delegate to the Map Analysis agent: full analysis of a zone or map point with risk, key findings and suggested actions. Use for "analyse", "what should we do", "suggest" requests.', {
    task: { type: 'string', description: 'What to analyse, in the user language' },
    zone_id: { type: 'string' },
    lat: { type: 'number' },
    lng: { type: 'number' }
  }, ['task']),
  tool('ask_weather_forecaster', 'Delegate to the Weather agent: 7-day weather prediction and weather-driven hazards for a zone or coordinate.', {
    task: { type: 'string', description: 'What to predict, in the user language' },
    zone_id: { type: 'string' },
    lat: { type: 'number' },
    lng: { type: 'number' }
  }, ['task'])
];

// Tools that control the website components (executed in the browser by the app)
const UI_TOOLS = [
  tool('navigate_section', 'Scroll the website to a section.', { section: { type: 'string', enum: SECTIONS } }, ['section']),
  tool('select_zone', 'Make a tracked zone the active zone on the hero section and map.', { zone_id: { type: 'string' } }, ['zone_id']),
  tool('open_search', 'Open the area search window, optionally with a query filled in.', { query: { type: 'string' } }),
  tool('open_demo_showreel', 'Open the demo showreel window.'),
  tool('toggle_selection_mode', 'Turn the map click-to-analyse mode on or off.', { enabled: { type: 'boolean' } }, ['enabled']),
  tool('map_fly_to', 'Move the map view to a coordinate.', {
    lat: { type: 'number' },
    lng: { type: 'number' },
    zoom: { type: 'number' }
  }, ['lat', 'lng']),
  tool('map_set_layer', 'Switch the map layer.', { layer: { type: 'string', enum: LAYERS } }, ['layer']),
  tool('map_analyze', 'Run the on-screen map analysis popup at a coordinate.', {
    lat: { type: 'number' },
    lng: { type: 'number' }
  }, ['lat', 'lng'])
];

const TOOLS = [...DATA_TOOLS, ...AGENT_TOOLS, ...UI_TOOLS];
const UI_TOOL_NAMES = new Set(UI_TOOLS.map(t => t.function.name));

function systemPrompt(activeZoneId?: string) {
  const zones = DISASTER_ZONES.map(z => `- ${z.id}: ${z.name} (${z.hazardType}, ${z.country})`).join('\n');
  const active = findZone(activeZoneId ?? '');
  return [
    'You are the Navigator agent (AI copilot) of a NASA-powered Disaster Risk Mapping website.',
    'You control the website with UI tools and read quick facts with data tools.',
    'You work in a team: ask_map_analyst does map analysis and suggestions, ask_weather_forecaster predicts weather. Delegate to them instead of guessing.',
    'Rules:',
    '- Use tools for every number or fact about zones, risks, events, weather or reports. Never invent figures.',
    '- When the user asks to see, open, go to or show something, call the matching UI tool. You may combine UI tools with a specialist call (e.g. fly the map there AND ask the map analyst).',
    '- If a tool returns an error or empty data, say so plainly.',
    '- Keep replies short (2-4 sentences, plain text, no markdown, no emojis because they are read aloud) and answer in the language the user wrote in (Hindi, Hinglish or English).',
    `Tracked zones:\n${zones}`,
    active ? `Zone currently on screen: ${active.id} (${active.name}).` : ''
  ].join('\n');
}

export interface AssistantResult {
  reply: string;
  actions: UiAction[];
  telemetry?: { satellite?: string; riskScore?: number };
  suggestions: string[];
  agentTrace: TraceEntry[];
  toolsUsed: string[];
}

export async function runAssistant(history: ChatMessage[], activeZoneId?: string): Promise<AssistantResult> {
  const ctx: AgentCtx = newCtx(activeZoneId);
  const actions: UiAction[] = [];
  let telemetry: AssistantResult['telemetry'];

  const { text, toolsUsed, exhausted } = await runToolLoop({
    agent: 'navigator',
    model: MODELS.navigator,
    messages: [
      { role: 'system', content: systemPrompt(activeZoneId) },
      ...history.slice(-20).map(m => ({ role: m.role, content: m.content }))
    ],
    tools: TOOLS,
    maxSteps: 6,
    runTool: async (name, a) => {
      if (UI_TOOL_NAMES.has(name)) {
        actions.push({ name, args: a });
        return { ok: true, note: 'Action queued on the user screen.' };
      }
      if (name === 'ask_map_analyst') return callAgent('navigator', 'map', String(a.task ?? 'Analyse the area'), a, ctx);
      if (name === 'ask_weather_forecaster') return callAgent('navigator', 'weather', String(a.task ?? 'Predict the weather'), a, ctx);

      const r: any = await runDataTool(name, a);
      if (name === 'get_zone_analysis' && r?.risk) {
        telemetry = { satellite: r.zone.satelliteMission, riskScore: r.risk.score };
      } else if (name === 'analyze_location' && r?.risk) {
        telemetry = { satellite: r.nearestZone.satelliteMission, riskScore: r.risk.score };
      }
      return r;
    }
  });

  return {
    reply: text || (exhausted ? 'I could not finish that request. Please try rephrasing it.' : 'Done.'),
    actions,
    telemetry,
    suggestions: [...new Set(ctx.shared.suggestions)].slice(0, 4),
    agentTrace: ctx.trace,
    toolsUsed
  };
}
