import { createHmac, randomBytes, randomUUID, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import type { NextFunction, Request, Response } from 'express';
import { getDb, saveDb, UserRecord } from './store';
import { HttpError } from './util';

const scrypt = promisify(scryptCb) as (password: string, salt: string, keylen: number) => Promise<Buffer>;

// Tokens stay valid across restarts only if AUTH_SECRET is set; otherwise a fresh secret is used per run
const SECRET = process.env.AUTH_SECRET || randomBytes(32).toString('hex');
const TOKEN_TTL_MS = 7 * 24 * 60 * 60 * 1000;

const b64 = (s: string) => Buffer.from(s).toString('base64url');
const sign = (payload: string) => createHmac('sha256', SECRET).update(payload).digest('base64url');

export const publicUser = (u: UserRecord) => ({ id: u.id, email: u.email, name: u.name });

function issueToken(userId: string) {
  const payload = b64(JSON.stringify({ uid: userId, exp: Date.now() + TOKEN_TTL_MS }));
  return `${payload}.${sign(payload)}`;
}

function readToken(token: string): string | null {
  const [payload, sig] = token.split('.');
  if (!payload || !sig) return null;
  const expected = Buffer.from(sign(payload));
  const given = Buffer.from(sig);
  if (expected.length !== given.length || !timingSafeEqual(expected, given)) return null;
  try {
    const { uid, exp } = JSON.parse(Buffer.from(payload, 'base64url').toString());
    return typeof uid === 'string' && exp > Date.now() ? uid : null;
  } catch {
    return null;
  }
}

export async function register(email: unknown, password: unknown, name: unknown) {
  const mail = String(email ?? '').trim().toLowerCase();
  const pass = String(password ?? '');
  const display = String(name ?? '').trim().slice(0, 60);
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) throw new HttpError(400, 'Enter a valid email address.');
  if (pass.length < 8) throw new HttpError(400, 'Password must be at least 8 characters.');
  if (!display) throw new HttpError(400, 'Name is required.');

  const db = getDb();
  if (db.users.some(u => u.email === mail)) throw new HttpError(409, 'An account with this email already exists.');

  const salt = randomBytes(16).toString('hex');
  const hash = (await scrypt(pass, salt, 64)).toString('hex');
  const user: UserRecord = { id: randomUUID(), email: mail, name: display, salt, hash, createdAt: Date.now() };
  db.users.push(user);
  saveDb();
  return { token: issueToken(user.id), user: publicUser(user) };
}

export async function login(email: unknown, password: unknown) {
  const mail = String(email ?? '').trim().toLowerCase();
  const user = getDb().users.find(u => u.email === mail);
  const fail = new HttpError(401, 'Wrong email or password.');
  if (!user) throw fail;
  const hash = await scrypt(String(password ?? ''), user.salt, 64);
  const stored = Buffer.from(user.hash, 'hex');
  if (hash.length !== stored.length || !timingSafeEqual(hash, stored)) throw fail;
  return { token: issueToken(user.id), user: publicUser(user) };
}

/** Sets res.locals.userId when a valid Bearer token is present; never blocks the request. */
export function authOptional(req: Request, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, '');
  const uid = token ? readToken(token) : null;
  if (uid && getDb().users.some(u => u.id === uid)) res.locals.userId = uid;
  next();
}

export function authRequired(req: Request, res: Response, next: NextFunction) {
  authOptional(req, res, () => {
    if (!res.locals.userId) return next(new HttpError(401, 'Login required.'));
    next();
  });
}
