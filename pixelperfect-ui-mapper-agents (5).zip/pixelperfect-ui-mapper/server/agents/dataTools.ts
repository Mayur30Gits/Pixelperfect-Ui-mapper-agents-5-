import { DISASTER_ZONES } from '../../src/data/disasterData';
import { analyzeLocation, analyzeZone, findZone, searchZones } from '../analysis';
import { getLiveEvents, getZoneHistory } from '../nasa';
import { getDb } from '../store';
import { parseCoords } from '../util';
import { tool } from './loop';

// Tools that read data on the server (zone search, map analysis, live NASA events, history, community)
export const DATA_TOOLS = [
  tool('search_zones', 'Search the tracked disaster zones by name, country, location or hazard type.', {
    query: { type: 'string' }
  }, ['query']),
  tool('get_zone_analysis', 'Risk score, tier and relief resource needs for one tracked zone.', {
    zone_id: { type: 'string' }
  }, ['zone_id']),
  tool('analyze_location', 'Analyse any map point: nearest tracked zone, risk if inside one, and nearby live NASA events.', {
    lat: { type: 'number' },
    lng: { type: 'number' }
  }, ['lat', 'lng']),
  tool('get_live_events', 'Currently open natural hazard events from NASA EONET.', {
    category: { type: 'string', description: 'EONET category id, e.g. wildfires, floods, severeStorms, earthquakes' },
    limit: { type: 'number' }
  }),
  tool('get_history', 'Past vs currently open events of the same hazard near a tracked zone.', {
    zone_id: { type: 'string' },
    days: { type: 'number', description: 'How many past days to look back (default 365)' }
  }, ['zone_id']),
  tool('get_community_reports', 'Latest community ground-truth reports.', { limit: { type: 'number' } })
];

export const brief = (z: ReturnType<typeof searchZones>[number]) => ({
  id: z.id,
  name: z.name,
  location: z.location,
  country: z.country,
  hazardType: z.hazardType,
  status: z.status,
  coordinates: z.coordinates
});

export async function runDataTool(name: string, a: Record<string, any>): Promise<unknown> {
  const zoneOrError = () => findZone(String(a.zone_id)) ?? null;
  const unknownZone = { error: 'Unknown zone_id', validIds: DISASTER_ZONES.map(z => z.id) };

  switch (name) {
    case 'search_zones':
      return searchZones(String(a.query ?? '')).map(brief);
    case 'get_zone_analysis': {
      const zone = zoneOrError();
      return zone ? analyzeZone(zone) : unknownZone;
    }
    case 'analyze_location': {
      const [lat, lng] = parseCoords(a.lat, a.lng);
      return analyzeLocation(lat, lng);
    }
    case 'get_live_events':
      return getLiveEvents({ category: a.category ? String(a.category) : undefined, limit: Math.min(Number(a.limit) || 10, 25) });
    case 'get_history': {
      const zone = zoneOrError();
      return zone ? getZoneHistory(zone, Number(a.days) || 365) : unknownZone;
    }
    case 'get_community_reports':
      return getDb()
        .reports.slice(0, Math.min(Number(a.limit) || 5, 10))
        .map(r => ({
          id: r.id,
          locationName: r.locationName,
          hazardType: r.hazardType,
          severity: r.severity,
          timestamp: r.timestamp,
          verified: r.verified,
          votes: r.votes,
          notes: r.notes
        }));
    default:
      return { error: `Unknown tool ${name}` };
  }
}

/** Resolve coordinates from either a tracked zone id or explicit lat/lng. */
export function resolveTarget(a: Record<string, any>, fallbackZoneId?: string): { lat: number; lng: number; label: string } | null {
  const zone = findZone(String(a.zone_id ?? '')) ?? (a.lat == null && a.lng == null ? findZone(fallbackZoneId ?? '') : undefined);
  if (zone) return { lat: zone.coordinates[0], lng: zone.coordinates[1], label: zone.name };
  if (a.lat != null && a.lng != null) {
    const [lat, lng] = parseCoords(a.lat, a.lng);
    return { lat, lng, label: `${lat.toFixed(2)}, ${lng.toFixed(2)}` };
  }
  return null;
}
