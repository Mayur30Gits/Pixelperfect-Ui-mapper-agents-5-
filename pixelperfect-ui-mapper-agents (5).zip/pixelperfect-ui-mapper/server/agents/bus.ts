// Agent bus: lets the AI agents call each other and share what they learned.
// navigator -> map / weather, weather -> map, map -> weather (loops are blocked).
import type { AgentName } from '../config';

export type ThinkingAgent = 'navigator' | 'map' | 'weather';

export interface TraceEntry {
  from: ThinkingAgent;
  to: ThinkingAgent;
  task: string;
  ok: boolean;
  ms: number;
}

export interface AgentCtx {
  activeZoneId?: string;
  depth: number;
  stack: ThinkingAgent[];
  trace: TraceEntry[]; // shared by reference across the whole request
  shared: { map?: unknown; weather?: unknown; suggestions: string[] }; // shared blackboard
}

export type AgentFn = (task: string, args: Record<string, any>, ctx: AgentCtx) => Promise<unknown>;

const MAX_DEPTH = 2;
const registry: Partial<Record<ThinkingAgent, AgentFn>> = {};

export const registerAgent = (name: ThinkingAgent, fn: AgentFn) => {
  registry[name] = fn;
};

export const newCtx = (activeZoneId?: string): AgentCtx => ({
  activeZoneId,
  depth: 0,
  stack: ['navigator'],
  trace: [],
  shared: { suggestions: [] }
});

/** One agent asks another agent to do a task. Never throws: errors come back as { error }. */
export async function callAgent(
  from: ThinkingAgent,
  to: ThinkingAgent,
  task: string,
  args: Record<string, any>,
  ctx: AgentCtx
): Promise<unknown> {
  const fn = registry[to];
  if (!fn) return { error: `Agent "${to}" is not available.` };
  if (ctx.depth >= MAX_DEPTH) return { error: 'Agent call depth limit reached; answer with what you already have.' };
  if (ctx.stack.includes(to)) return { error: `Agent "${to}" is already working on this request.` };

  const child: AgentCtx = { ...ctx, depth: ctx.depth + 1, stack: [...ctx.stack, to] };
  const started = Date.now();
  try {
    const result = await fn(task, args, child);
    ctx.trace.push({ from, to, task: task.slice(0, 120), ok: true, ms: Date.now() - started });
    return result;
  } catch (err) {
    ctx.trace.push({ from, to, task: task.slice(0, 120), ok: false, ms: Date.now() - started });
    return { error: err instanceof Error ? err.message : `Agent "${to}" failed.` };
  }
}

export type { AgentName };
