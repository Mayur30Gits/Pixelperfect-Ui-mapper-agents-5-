import { AgentName } from '../config';
import { groqChat } from '../groqClient';
import { HttpError } from '../util';

export interface ToolDef {
  type: 'function';
  function: { name: string; description: string; parameters: unknown };
}

export const tool = (name: string, description: string, properties: Record<string, unknown> = {}, required: string[] = []): ToolDef => ({
  type: 'function',
  function: { name, description, parameters: { type: 'object', properties, required } }
});

interface LoopOpts {
  agent: AgentName;
  model: string;
  messages: any[];
  tools: ToolDef[];
  maxSteps?: number;
  temperature?: number;
  /** runs one tool call and returns the result that goes back to the model */
  runTool: (name: string, args: Record<string, any>) => Promise<unknown>;
}

/** Shared function-calling loop used by every thinking agent. */
export async function runToolLoop(o: LoopOpts): Promise<{ text: string; toolsUsed: string[]; exhausted: boolean }> {
  const messages = [...o.messages];
  const toolsUsed: string[] = [];
  let retried = false;

  for (let step = 0; step < (o.maxSteps ?? 6); step++) {
    let data: any;
    try {
      data = await groqChat(o.agent, {
        model: o.model,
        messages,
        tools: o.tools,
        tool_choice: 'auto',
        temperature: o.temperature ?? 0.3
      });
    } catch (err) {
      // Models occasionally emits a malformed tool call; one retry usually fixes it
      if (err instanceof HttpError && err.status === 400 && err.message.includes('tool_use_failed') && !retried) {
        retried = true;
        continue;
      }
      throw err;
    }

    const msg = data.choices?.[0]?.message;
    if (!msg) throw new HttpError(502, 'Groq returned an empty response.');
    if (!msg.tool_calls?.length) return { text: String(msg.content ?? '').trim(), toolsUsed, exhausted: false };

    messages.push({ role: 'assistant', content: msg.content ?? null, tool_calls: msg.tool_calls });

    for (const call of msg.tool_calls) {
      const name: string = call.function?.name;
      let args: Record<string, any> = {};
      try {
        args = JSON.parse(call.function?.arguments || '{}');
      } catch {
        // malformed arguments: the tool itself will report what is missing
      }
      toolsUsed.push(name);
      let result: unknown;
      try {
        result = await o.runTool(name, args);
      } catch (err) {
        result = { error: err instanceof Error ? err.message : 'Tool failed' };
      }
      messages.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result).slice(0, 6000) });
    }
  }
  return { text: '', toolsUsed, exhausted: true };
}

/** Pull a JSON object out of a model reply (handles ```json fences and extra prose). */
export function parseJsonLoose<T>(text: string): T | null {
  const cleaned = text.replace(/```json|```/g, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(cleaned.slice(start, end + 1)) as T;
  } catch {
    return null;
  }
}
