// Agent 2: map analysis + result/suggestion output (own Groq key)
import { DISASTER_ZONES } from '../../src/data/disasterData';
import { MODELS } from '../config';
import { callAgent, registerAgent } from './bus';
import { DATA_TOOLS, resolveTarget, runDataTool } from './dataTools';
import { parseJsonLoose, runToolLoop, tool } from './loop';

export interface MapReport {
  summary: string;
  riskLevel: 'low' | 'moderate' | 'high' | 'critical' | 'unknown';
  keyFindings: string[];
  suggestions: string[];
  weatherNote?: string;
}

const TOOLS = [
  ...DATA_TOOLS,
  tool('consult_weather_forecaster', 'Ask the weather agent for the 7-day forecast outlook of a zone or coordinate.', {
    zone_id: { type: 'string' },
    lat: { type: 'number' },
    lng: { type: 'number' }
  })
];

const SYSTEM = [
  'You are the Map Analysis agent of a NASA-powered Disaster Risk Mapping website.',
  'Analyse the requested zone or map point using the data tools. Never invent numbers; use only tool results.',
  'If upcoming weather could change the risk, call consult_weather_forecaster once.',
  'Finish with ONLY a JSON object, no prose, in this exact shape:',
  '{"summary": string (2-3 sentences), "riskLevel": "low"|"moderate"|"high"|"critical"|"unknown", "keyFindings": string[] (max 4), "suggestions": string[] (3-4 short, actionable steps for responders or residents), "weatherNote": string (optional)}',
  'Write the text fields in the language the task is written in (Hindi, Hinglish or English).',
  `Tracked zones:\n${DISASTER_ZONES.map(z => `- ${z.id}: ${z.name} (${z.hazardType}, ${z.country})`).join('\n')}`
].join('\n');

registerAgent('map', async (task, args, ctx) => {
  const target = resolveTarget(args, ctx.activeZoneId);
  const hint = target ? `\nTarget: ${target.label} (lat ${target.lat}, lng ${target.lng}).` : '';
  const { text, exhausted } = await runToolLoop({
    agent: 'map',
    model: MODELS.map,
    messages: [
      { role: 'system', content: SYSTEM },
      { role: 'user', content: task + hint }
    ],
    tools: TOOLS,
    maxSteps: 5,
    runTool: async (name, a) => {
      if (name === 'consult_weather_forecaster') {
        const w = await callAgent('map', 'weather', `Forecast outlook for ${target?.label ?? 'this area'}`, { ...a, ...(target && a.lat == null && !a.zone_id ? { lat: target.lat, lng: target.lng } : {}) }, ctx);
        return w;
      }
      return runDataTool(name, a);
    }
  });

  const report: MapReport = parseJsonLoose<MapReport>(text) ?? {
    summary: exhausted ? 'Map analysis could not be completed.' : text || 'No analysis available.',
    riskLevel: 'unknown',
    keyFindings: [],
    suggestions: []
  };
  report.suggestions = Array.isArray(report.suggestions) ? report.suggestions.slice(0, 4).map(String) : [];
  ctx.shared.map = report;
  ctx.shared.suggestions.push(...report.suggestions);
  return report;
});
