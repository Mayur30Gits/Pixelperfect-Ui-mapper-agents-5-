// Agent 3: weather prediction (own Groq key). Forecast data from Open-Meteo, interpretation by Groq.
import { MODELS } from '../config';
import { getForecast } from '../weather';
import { AgentCtx, callAgent, registerAgent } from './bus';
import { resolveTarget } from './dataTools';
import { parseJsonLoose, runToolLoop, tool } from './loop';

export interface WeatherReport {
  summary: string;
  hazards: { type: string; level: 'low' | 'moderate' | 'high' | 'extreme'; when: string }[];
  outlook: string;
  advice: string[];
}

const TOOLS = [
  tool('get_forecast', 'Real 7-day forecast (temperature, rain, wind, gusts) for a zone or coordinate.', {
    zone_id: { type: 'string' },
    lat: { type: 'number' },
    lng: { type: 'number' }
  }),
  tool('consult_map_analyst', 'Ask the map analysis agent about current disaster risk at this place, to combine with the forecast.', {
    zone_id: { type: 'string' },
    lat: { type: 'number' },
    lng: { type: 'number' }
  })
];

const SYSTEM = [
  'You are the Weather Prediction agent of a NASA-powered Disaster Risk Mapping website.',
  'Call get_forecast first. Base every statement on the returned numbers; never invent weather data.',
  'Predict weather-driven hazards for the next 7 days (flood from heavy rain, storm/cyclone winds, heat and wildfire danger, etc.).',
  'You may call consult_map_analyst once if current disaster risk would sharpen the prediction.',
  'Finish with ONLY a JSON object, no prose, in this exact shape:',
  '{"summary": string (2 sentences), "hazards": [{"type": string, "level": "low"|"moderate"|"high"|"extreme", "when": string}], "outlook": string (one sentence for days 4-7), "advice": string[] (max 3)}',
  'Write the text fields in the language the task is written in (Hindi, Hinglish or English).'
].join('\n');

registerAgent('weather', async (task, args, ctx: AgentCtx) => {
  const target = resolveTarget(args, ctx.activeZoneId);
  if (!target) return { error: 'Weather agent needs a zone_id or lat/lng.' };

  const { text, exhausted } = await runToolLoop({
    agent: 'weather',
    model: MODELS.weather,
    messages: [
      { role: 'system', content: SYSTEM },
      { role: 'user', content: `${task}\nTarget: ${target.label} (lat ${target.lat}, lng ${target.lng}).` }
    ],
    tools: TOOLS,
    maxSteps: 4,
    runTool: async (name, a) => {
      const t = resolveTarget(a, ctx.activeZoneId) ?? target;
      if (name === 'get_forecast') return getForecast(t.lat, t.lng);
      if (name === 'consult_map_analyst') return callAgent('weather', 'map', `Current disaster risk summary for ${t.label}`, { lat: t.lat, lng: t.lng }, ctx);
      return { error: `Unknown tool ${name}` };
    }
  });

  const report: WeatherReport = parseJsonLoose<WeatherReport>(text) ?? {
    summary: exhausted ? 'Weather prediction could not be completed.' : text || 'No prediction available.',
    hazards: [],
    outlook: '',
    advice: []
  };
  ctx.shared.weather = report;
  return report;
});
