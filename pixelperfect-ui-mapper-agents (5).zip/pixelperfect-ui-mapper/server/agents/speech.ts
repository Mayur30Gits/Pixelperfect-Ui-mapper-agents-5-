// Agent 4 (speech to text) and Agent 5 (text to speech), each with its own Groq key.
import { MODELS, STT_LANGUAGE, TTS_VOICE } from '../config';
import { groqSpeech, groqTranscribe } from '../groqClient';
import { HttpError } from '../util';

const EXT: Record<string, string> = { webm: 'webm', ogg: 'ogg', mp4: 'm4a', mpeg: 'mp3', mp3: 'mp3', wav: 'wav', 'x-wav': 'wav', 'x-m4a': 'm4a' };

export async function speechToText(audio: Buffer, mime: string): Promise<{ text: string; language?: string }> {
  if (!audio.length) throw new HttpError(400, 'Empty audio.');
  if (audio.length > 24 * 1024 * 1024) throw new HttpError(413, 'Audio is too large.');
  const sub = (mime.split('/')[1] ?? 'webm').split(';')[0].trim();
  const form = new FormData();
  form.append('file', new Blob([new Uint8Array(audio)], { type: mime || 'audio/webm' }), `voice.${EXT[sub] ?? 'webm'}`);
  form.append('model', MODELS.stt);
  form.append('response_format', 'verbose_json');
  form.append('temperature', '0');
  form.append('prompt', 'Disaster mapping assistant. Hindi, Hinglish or English: flood, wildfire, cyclone, earthquake, map, zone, weather.');
  if (STT_LANGUAGE) form.append('language', STT_LANGUAGE);
  const data = await groqTranscribe('stt', form);
  return { text: String(data.text ?? '').trim(), language: data.language };
}

const MAX_TTS_CHARS = 200; // Orpheus limit per request

export async function textToSpeech(text: string, voice?: string): Promise<Buffer> {
  const input = text.trim();
  if (!input) throw new HttpError(400, 'text is required.');
  if (input.length > MAX_TTS_CHARS) throw new HttpError(400, `text must be at most ${MAX_TTS_CHARS} characters; split it into sentences.`);
  return groqSpeech('tts', {
    model: MODELS.tts,
    input,
    voice: voice || TTS_VOICE,
    response_format: 'wav'
  });
}
