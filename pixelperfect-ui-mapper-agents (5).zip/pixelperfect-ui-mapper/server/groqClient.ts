import { AGENT_KEYS, AgentName, CHAT_FALLBACK_MODELS, GROQ_BASE, GROQ_URL } from './config';
import { HttpError } from './util';

export function keyFor(agent: AgentName): string {
  const key = AGENT_KEYS[agent];
  if (!key) {
    throw new HttpError(
      503,
      `Groq key for the "${agent}" agent is not set. Add GROQ_KEY_${agent.toUpperCase()} (or GROQ_API_KEY) to .env.local and restart the server.`
    );
  }
  return key;
}

async function failFrom(res: Response, agent: AgentName): Promise<never> {
  const text = (await res.text()).slice(0, 300);
  if (res.status === 401) throw new HttpError(502, `Groq rejected the "${agent}" agent key. Check GROQ_KEY_${agent.toUpperCase()}.`);
  if (res.status === 429) throw new HttpError(429, `Groq rate limit reached for the "${agent}" agent. Try again in a moment.`);
  throw new HttpError(res.status === 400 ? 400 : 502, `Groq error (${agent}): ${text}`);
}

const isModelGone = (status: number, text: string) =>
  (status === 400 || status === 404) && /model_decommissioned|model_not_found|decommissioned|does not exist|no longer supported/i.test(text);

/** Chat completion for one agent, using that agent's own key. Falls back to other models if the model was retired. */
export async function groqChat(agent: AgentName, body: unknown): Promise<any> {
  const base = body as Record<string, any>;
  const models = [base.model, ...CHAT_FALLBACK_MODELS.filter((m) => m !== base.model)];
  let lastRes: Response | null = null;

  for (const model of models) {
    const res = await fetch(GROQ_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${keyFor(agent)}` },
      body: JSON.stringify({ ...base, model }),
      signal: AbortSignal.timeout(30_000)
    });
    if (res.ok) return res.json();
    const text = await res.clone().text();
    lastRes = res;
    if (!isModelGone(res.status, text)) break;
    console.warn(`Groq model "${model}" unavailable for "${agent}" agent, trying next fallback.`);
  }
  return failFrom(lastRes as Response, agent);
}

/** multipart upload (speech to text) */
export async function groqTranscribe(agent: AgentName, form: FormData): Promise<any> {
  const res = await fetch(`${GROQ_BASE}/audio/transcriptions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${keyFor(agent)}` },
    body: form,
    signal: AbortSignal.timeout(30_000)
  });
  if (!res.ok) await failFrom(res, agent);
  return res.json();
}

/** text to speech: returns raw audio bytes */
export async function groqSpeech(agent: AgentName, body: unknown): Promise<Buffer> {
  const res = await fetch(`${GROQ_BASE}/audio/speech`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${keyFor(agent)}` },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30_000)
  });
  if (!res.ok) await failFrom(res, agent);
  return Buffer.from(await res.arrayBuffer());
}
