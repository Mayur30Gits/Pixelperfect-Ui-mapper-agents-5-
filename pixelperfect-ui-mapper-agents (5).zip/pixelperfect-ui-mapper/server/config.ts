import dotenv from 'dotenv';

dotenv.config({ path: '.env.local' });
dotenv.config();

// Placeholder values copied from .env.example (MY_...) count as "not set"
// A model name must never look like a key or a retired model; ignore such env values
const model = (v: string | undefined, fallback: string) =>
  v && !v.startsWith('gsk_') && !/llama-3\.3-70b-versatile/.test(v) ? v.trim() : fallback;

const real = (v?: string) => (v && !v.startsWith('MY_') ? v.trim() : '');

export const PORT = Number(process.env.PORT) || 3000;
export const IS_PROD = process.env.NODE_ENV === 'production';

export const GROQ_BASE = 'https://api.groq.com/openai/v1';
export const GROQ_URL = `${GROQ_BASE}/chat/completions`;

// Fallback key: used by any agent that has no key of its own
export const GROQ_API_KEY = real(process.env.GROQ_API_KEY);

/**
 * Multi-agent setup: every AI agent has its own Groq key.
 *   navigator -> navigation + function calling (orchestrator)
 *   map       -> map analysis + result/suggestion output
 *   weather   -> weather prediction
 *   stt       -> speech to text
 *   tts       -> text to speech
 */
export type AgentName = 'navigator' | 'map' | 'weather' | 'stt' | 'tts';

export const AGENT_KEYS: Record<AgentName, string> = {
  navigator: real(process.env.GROQ_KEY_NAVIGATOR) || GROQ_API_KEY,
  map: real(process.env.GROQ_KEY_MAP) || GROQ_API_KEY,
  weather: real(process.env.GROQ_KEY_WEATHER) || GROQ_API_KEY,
  stt: real(process.env.GROQ_KEY_STT) || GROQ_API_KEY,
  tts: real(process.env.GROQ_KEY_TTS) || GROQ_API_KEY
};

// Models (all overridable from .env in case Groq retires one)
export const MODELS = {
  navigator: model(process.env.GROQ_MODEL_NAVIGATOR, 'openai/gpt-oss-120b'),
  map: model(process.env.GROQ_MODEL_MAP, 'openai/gpt-oss-120b'),
  weather: model(process.env.GROQ_MODEL_WEATHER, 'openai/gpt-oss-120b'),
  stt: process.env.GROQ_MODEL_STT || 'whisper-large-v3-turbo',
  tts: process.env.GROQ_MODEL_TTS || 'canopylabs/orpheus-v1-english'
};
export const GROQ_MODEL = MODELS.navigator;

// Groq shut down llama-3.3-70b-versatile on 2026-08-16. If a chat model is rejected as
// decommissioned / not found, groqChat automatically tries these in order.
export const CHAT_FALLBACK_MODELS = (process.env.GROQ_FALLBACK_MODELS || 'qwen/qwen3.6-27b,openai/gpt-oss-20b')
  .split(',')
  .map((m) => m.trim())
  .filter(Boolean);

export const TTS_VOICE = process.env.GROQ_TTS_VOICE || 'troy';
export const STT_LANGUAGE = process.env.GROQ_STT_LANGUAGE || ''; // e.g. "hi" or "en"; empty = auto-detect

// Reuses the NASA key already listed in .env.example (DEMO_KEY works with low rate limits)
export const NASA_API_KEY = real(process.env.NASA_API_KEY) || real(process.env.VITE_NASA_API_KEY) || 'DEMO_KEY';
