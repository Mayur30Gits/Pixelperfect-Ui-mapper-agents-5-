import { DISASTER_ZONES, DisasterZoneDetail } from '../src/data/disasterData';
import {
  calculateDisasterSeverity,
  calculateDistanceKm,
  estimateRescueResourceNeeds,
  findNearestDisasterZone
} from '../src/utils/disasterCalculations';
import { getLiveEvents } from './nasa';

// A map point counts as "inside" a tracked zone when it is this close to the zone centre
const ZONE_INFLUENCE_KM = 300;
// Live NASA events within this distance are reported as nearby
const NEARBY_EVENT_KM = 500;

export const findZone = (id: string) => DISASTER_ZONES.find(z => z.id === id);

/** Same matching rules as the website's search modal. */
export function searchZones(query: string): DisasterZoneDetail[] {
  const q = query.trim().toLowerCase();
  if (!q) return DISASTER_ZONES;
  return DISASTER_ZONES.filter(
    z =>
      z.name.toLowerCase().includes(q) ||
      z.country.toLowerCase().includes(q) ||
      z.location.toLowerCase().includes(q) ||
      z.hazardType.toLowerCase().includes(q)
  );
}

/** AI analysis backend: risk score + relief needs for a tracked zone (uses the site's own formulas). */
export function analyzeZone(zone: DisasterZoneDetail) {
  const risk = calculateDisasterSeverity(
    zone.hazardIntensity,
    zone.vulnerabilityIndex,
    zone.populationAtRisk,
    zone.readinessScore
  );
  const resources = estimateRescueResourceNeeds(zone.populationAtRisk, risk.score, zone.areaKm2);
  return {
    zone: {
      id: zone.id,
      name: zone.name,
      location: zone.location,
      country: zone.country,
      hazardType: zone.hazardType,
      status: zone.status,
      coordinates: zone.coordinates,
      satelliteMission: zone.satelliteMission,
      summary: zone.summary,
      damageHighlights: zone.damageHighlights
    },
    risk,
    resources
  };
}

/** Map analysis: what is known about an arbitrary point (nearest tracked zone + live NASA events). */
export async function analyzeLocation(lat: number, lng: number) {
  const nearest = findNearestDisasterZone(lat, lng, DISASTER_ZONES)!;

  let liveEventsAvailable = true;
  const live = await getLiveEvents({ limit: 100 }).catch(() => {
    liveEventsAvailable = false;
    return [];
  });
  const nearbyLiveEvents = live
    .map(e => ({ ...e, distanceKm: calculateDistanceKm(lat, lng, e.coordinates[0], e.coordinates[1]) }))
    .filter(e => e.distanceKm <= NEARBY_EVENT_KM)
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, 5);

  const withinTrackedZone = nearest.distanceKm <= ZONE_INFLUENCE_KM;
  const zoneAnalysis = withinTrackedZone ? analyzeZone(nearest.zone) : null;

  return {
    coords: [lat, lng] as [number, number],
    nearestZone: {
      id: nearest.zone.id,
      name: nearest.zone.name,
      hazardType: nearest.zone.hazardType,
      satelliteMission: nearest.zone.satelliteMission,
      distanceKm: nearest.distanceKm
    },
    withinTrackedZone,
    risk: zoneAnalysis?.risk ?? null,
    resources: zoneAnalysis?.resources ?? null,
    nearbyLiveEvents,
    liveEventsAvailable
  };
}
