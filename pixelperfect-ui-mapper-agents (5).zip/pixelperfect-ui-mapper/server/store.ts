import fs from 'node:fs';
import path from 'node:path';
import { CommunityReport, INITIAL_REPORTS } from '../src/data/disasterData';

export interface UserRecord {
  id: string;
  email: string;
  name: string;
  salt: string;
  hash: string;
  createdAt: number;
}

interface DB {
  reports: (CommunityReport & { userId?: string })[];
  users: UserRecord[];
}

// Simple JSON-file database (no extra dependency). Swap for Firebase/Supabase later if needed.
const FILE = path.resolve(process.cwd(), 'server/data/db.json');
let db: DB | null = null;

export function saveDb() {
  if (!db) return;
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, FILE);
}

export function getDb(): DB {
  if (db) return db;
  try {
    db = JSON.parse(fs.readFileSync(FILE, 'utf8')) as DB;
  } catch {
    db = { reports: structuredClone(INITIAL_REPORTS), users: [] };
    saveDb();
  }
  return db;
}
