import { cached, HttpError } from './util';

export interface Forecast {
  lat: number;
  lng: number;
  timezone: string;
  current: Record<string, number | string>;
  daily: {
    date: string;
    tempMaxC: number;
    tempMinC: number;
    rainMm: number;
    rainProbPct: number | null;
    windMaxKmh: number;
    gustMaxKmh: number;
  }[];
}

/** 7-day forecast from Open-Meteo (free, no API key). Cached 15 minutes. */
export function getForecast(lat: number, lng: number): Promise<Forecast> {
  const key = `wx:${lat.toFixed(2)},${lng.toFixed(2)}`;
  return cached(key, 15 * 60_000, async () => {
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
      `&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m,wind_gusts_10m,surface_pressure` +
      `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max` +
      `&forecast_days=7&timezone=auto`;
    let res: Response;
    try {
      res = await fetch(url, { signal: AbortSignal.timeout(10_000) });
    } catch {
      throw new HttpError(502, 'Weather service (Open-Meteo) is unreachable right now.');
    }
    if (!res.ok) throw new HttpError(502, `Weather service error (${res.status}).`);
    const d: any = await res.json();
    const daily = (d.daily?.time ?? []).map((date: string, i: number) => ({
      date,
      tempMaxC: d.daily.temperature_2m_max[i],
      tempMinC: d.daily.temperature_2m_min[i],
      rainMm: d.daily.precipitation_sum[i],
      rainProbPct: d.daily.precipitation_probability_max?.[i] ?? null,
      windMaxKmh: d.daily.wind_speed_10m_max[i],
      gustMaxKmh: d.daily.wind_gusts_10m_max[i]
    }));
    return { lat, lng, timezone: d.timezone, current: d.current ?? {}, daily } as Forecast;
  });
}
